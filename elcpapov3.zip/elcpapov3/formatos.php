<!DOCTYPE html>
<html lang="en">
<head>
  <title>Formatos</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="estiloformatos.css">
  <link rel="stylesheet" href="css/estilosTexto.css">
 
   <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
 <?php
    include("navbar.php");
    ?>
<center>
<center>
    <div class="texto marco" style="float: none;">
        <div class="titulo">
            <h1>FORMATOS</h1>  
        </div>
    </div>
</center>
</center>

        <div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div class="panel-group" id="accordion">
                
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #1C8C65">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" style="color: #fff">Servicio Social</a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <a href="Archivos/SERVICIO-SOCIAL/Formato-1-programa-de-actividades-SERVICIO.doc" style="color: #1C8C65">Formato 1 Programa de Actividades</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="Archivos/SERVICIO-SOCIAL/FORMATO-2-reporte-MENSUAL-SERVICIO.doc" style="color: #1C8C65">Formato 2 Reporte mensual</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="Archivos/SERVICIO-SOCIAL/ServicioSocial.docx" style="color: #1C8C65">Procedimiento para el trámite</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #1C8C65">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" style="color: #fff">Residencias</a>
                        </h4>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <a href="Archivos/PRACTICAS-PROFESIONALES/Formatos-1-Programa-de-actividades.doc" style="color: #1C8C65">Formato 1 Programa de Actividades</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="Archivos/PRACTICAS-PROFESIONALES/Formato-2-Informe-de-actividades-semanales.doc" style="color: #1C8C65">Formato 2 Reporte Mensual</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="Archivos/PRACTICAS-PROFESIONALES/ForProcedimiento-PracticasProfesionales.docx" style="color: #1C8C65">Procedimiento para el trámite</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #1C8C65">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour" style="color: #fff">Constancias</a>
                        </h4>
                    </div>
                    <div id="collapseFour" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <a href="#tab7" style="color: #1C8C65">Formato 1</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#tab8" style="color: #1C8C65">Formato 2</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#tab9" style="color: #1C8C65">Formato 3</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
   include("footer.php") 
   ?>

</body>
</html>



