<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <link rel="stylesheet" href="css/w3.css">
        <script src="js/jquery.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/estilosTexto.css">
<style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}


/* Style the tab */
div.tab {
    float: left;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
    width: 15%;
    height: auto;
}

/* Style the buttons inside the tab */
div.tab button {
    display: block;
    background-color: inherit;
    color: black;
    padding: 22px 16px;
    width: 100%;
    border: none;
    outline: none;
    text-align: left;
    cursor: pointer;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
div.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current "tab button" class */
div.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    float: left;
    padding: 0px 12px;
    width: 80%;
    height: auto;
    border-left: none;
}
.contenidobiblioteca{
    max-width: 1200px; width: 95%; margin: auto;
}
</style>
</head>
<body>
<?php include("navbar.php"); ?>

<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Agregar Nueva Palabra</h4>
        </div>
        <div class="modal-body">
        <form action="user/registrarPalabra.php" method="post">
            <label class="control-label"> Palabra: </label>
            <input class="form-control" type="text" name="palabra">
            <label class="control-label">Significado: </label>
            <input class="form-control" type="text" name="significado">
            <input class="btn btn-primary" type="submit" name="enviar" value="Registrar">
          </form>
        </div>
        <div class="modal-footer">
        </div>
      </div> 
    </div>
  </div>

<div class="titulo"> 
  <center><h2><strong>Diccionario Virtual</strong></h2></center>
</div>
<br>
<label style="padding-left: 50px;">Agregar Nueva Palabra</label>
<button style="margin: : auto;" class="btn" data-toggle="modal" data-target="#myModal">+</button><br><br>
<div class="contenidobiblioteca">
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'intro')" id="defaultOpen"></button>
  <button class="tablinks" onclick="openCity(event, 'a')">A</button>
  <button class="tablinks" onclick="openCity(event, 'b')">B</button>
  <button class="tablinks" onclick="openCity(event, 'c')">C</button>
  <button class="tablinks" onclick="openCity(event, 'd')">D</button>
  <button class="tablinks" onclick="openCity(event, 'e')">E</button>
  <button class="tablinks" onclick="openCity(event, 'f')">F</button>
  <button class="tablinks" onclick="openCity(event, 'g')">G</button>
  <button class="tablinks" onclick="openCity(event, 'h')">H</button>
  <button class="tablinks" onclick="openCity(event, 'i')">I</button>
  <button class="tablinks" onclick="openCity(event, 'j')">J</button>
  <button class="tablinks" onclick="openCity(event, 'k')">K</button>
  <button class="tablinks" onclick="openCity(event, 'l')">L</button>
  <button class="tablinks" onclick="openCity(event, 'm')">M</button>
  <button class="tablinks" onclick="openCity(event, 'n')">N</button>
  <button class="tablinks" onclick="openCity(event, 'o')">O</button>
  <button class="tablinks" onclick="openCity(event, 'p')">P</button>
  <button class="tablinks" onclick="openCity(event, 'q')">Q</button>
  <button class="tablinks" onclick="openCity(event, 'r')">R</button>
  <button class="tablinks" onclick="openCity(event, 's')">S</button>
  <button class="tablinks" onclick="openCity(event, 't')">T</button>
  <button class="tablinks" onclick="openCity(event, 'u')">U</button>
  <button class="tablinks" onclick="openCity(event, 'v')">V</button>
  <button class="tablinks" onclick="openCity(event, 'w')">W</button>
  <button class="tablinks" onclick="openCity(event, 'x')">X</button>
  <button class="tablinks" onclick="openCity(event, 'y')">Y</button>
  <button class="tablinks" onclick="openCity(event, 'z')">Z</button>
</div>

<div id="intro" class="tabcontent">
  <h3></h3>
   La Escuela Libre de Ciencias Políticas y Administración Pública de Oriente, como una universidad promotora de los valores de la educación,  establece las herramientas necesarias a los estudiantes o interesados en la materia de derecho sin el ánimo de lucro y promoviendo la educación en todos sus niveles, primaria, secundaria, preparatoria, licenciatura, maestría y doctorado.
  Éste diccionario es un esfuerzo para darle al visitante los conceptos en materia de DERECHO en una forma gratuita y libre, sin suscripciones.
  En la parte superior con solo seleccionar una letra, se encontrarán los conceptos recabados
  Sean bienvenidos, ésta es su universidad.
</div>

<div id="a" class="tabcontent">
  <h3>A</h3>
    <?php
      try {
        $base = new PDO('mysql:host=localhost; dbname=elcpapo','root','serena1');
        
        $base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $base->exec("SET CHARACTER SET UTF8");
        
    }catch(Exception $e) {
        die('Error'. $e->getMessage());
        echo "linea del error" . $e->gerLine();
    }
      $sqlA="SELECT * FROM diccionario where estado='aprobado' and palabra like 'a%';";
      $conexion=$base->query($sqlA);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<div id="b" class="tabcontent">
  <h3>B</h3>
    <?php
      $sqlB="SELECT * FROM diccionario where estado='aprobado' and palabra like 'b%';";
      $conexion=$base->query($sqlB);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<div id="c" class="tabcontent">
  <h3>C</h3>
    <?php
      $sqlC="SELECT * FROM diccionario where estado='aprobado' and palabra like 'c%';";
      $conexion=$base->query($sqlC);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<div id="d" class="tabcontent">
  <h3>D</h3>
    <?php
      $sqlD="SELECT * FROM diccionario where estado='aprobado' and palabra like 'd%';";
      $conexion=$base->query($sqlD);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<div id="e" class="tabcontent">
  <h3>E</h3>
     <?php
      $sqlE="SELECT * FROM diccionario where estado='aprobado' and palabra like 'e%';";
      $conexion=$base->query($sqlE);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="f" class="tabcontent">
  <h3>F</h3>
      <?php
      $sqlF="SELECT * FROM diccionario where estado='aprobado' and palabra like 'f%';";
      $conexion=$base->query($sqlF);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="g" class="tabcontent">
  <h3>G</h3>
  <?php
      $sqlG="SELECT * FROM diccionario where estado='aprobado' and palabra like 'g%';";
      $conexion=$base->query($sqlG);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="h" class="tabcontent">
  <h3>H</h3>
  <?php
      $sqlH="SELECT * FROM diccionario where estado='aprobado' and palabra like 'h%';";
      $conexion=$base->query($sqlH);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?> 
</div>
<div id="i" class="tabcontent">
  <h3>I</h3>
  <?php
      $sqlI="SELECT * FROM diccionario where estado='aprobado' and palabra like 'i%';";
      $conexion=$base->query($sqlI);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="j" class="tabcontent">
  <h3>J</h3>
  <?php
      $sqlJ="SELECT * FROM diccionario where estado='aprobado' and palabra like 'j%';";
      $conexion=$base->query($sqlJ);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="k" class="tabcontent">
  <h3>K</h3>
  <?php
      $sqlK="SELECT * FROM diccionario where estado='aprobado' and palabra like 'k%';";
      $conexion=$base->query($sqlK);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="l" class="tabcontent">
  <h3>L</h3>
  <?php
      $sqlL="SELECT * FROM diccionario where estado='aprobado' and palabra like 'l%';";
      $conexion=$base->query($sqlL);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="m" class="tabcontent">
  <h3>M</h3>
  <?php
      $sqlM="SELECT * FROM diccionario where estado='aprobado' and palabra like 'm%';";
      $conexion=$base->query($sqlM);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="n" class="tabcontent">
  <h3>N</h3>
  <?php
      $sqlN="SELECT * FROM diccionario where estado='aprobado' and palabra like 'n%';";
      $conexion=$base->query($sqlN);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="o" class="tabcontent">
  <h3>O</h3>
  <?php
      $sqlO="SELECT * FROM diccionario where estado='aprobado' and palabra like 'o%';";
      $conexion=$base->query($sqlO);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="p" class="tabcontent">
  <h3>P</h3>
  <?php
      $sqlP="SELECT * FROM diccionario where estado='aprobado' and palabra like 'p%';";
      $conexion=$base->query($sqlP);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="q" class="tabcontent">
  <h3>Q</h3>
  <?php
      $sqlQ="SELECT * FROM diccionario where estado='aprobado' and palabra like 'q%';";
      $conexion=$base->query($sqlQ);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="r" class="tabcontent">
  <h3>R</h3>
  <?php
      $sqlR="SELECT * FROM diccionario where estado='aprobado' and palabra like 'r%';";
      $conexion=$base->query($sqlR);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="s" class="tabcontent">
  <h3>S</h3>
  <?php
      $sqlS="SELECT * FROM diccionario where estado='aprobado' and palabra like 's%';";
      $conexion=$base->query($sqlS);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="t" class="tabcontent">
  <h3>T</h3>
  <?php
      $sqlT="SELECT * FROM diccionario where estado='aprobado' and palabra like 't%';";
      $conexion=$base->query($sqlT);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="u" class="tabcontent">
  <h3>U</h3>
  <?php
      $sqlU="SELECT * FROM diccionario where estado='aprobado' and palabra like 'u%';";
      $conexion=$base->query($sqlU);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="v" class="tabcontent">
  <h3>V</h3>
  <?php
      $sqlV="SELECT * FROM diccionario where estado='aprobado' and palabra like 'v%';";
      $conexion=$base->query($sqlV);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="w" class="tabcontent">
  <h3>W</h3>
  <?php
      $sqlW="SELECT * FROM diccionario where estado='aprobado' and palabra like 'w%';";
      $conexion=$base->query($sqlW);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="x" class="tabcontent">
  <h3>X</h3>
  <?php
      $sqlX="SELECT * FROM diccionario where estado='aprobado' and palabra like 'x%';";
      $conexion=$base->query($sqlX);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="y" class="tabcontent">
  <h3>Y</h3>
  <?php
      $sqlY="SELECT * FROM diccionario where estado='aprobado' and palabra like 'y%';";
      $conexion=$base->query($sqlY);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
<div id="z" class="tabcontent">
  <h3>Z</h3>
  <?php
      $sqlZ="SELECT * FROM diccionario where estado='aprobado' and palabra like 'z%';";
      $conexion=$base->query($sqlZ);
      $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    <?php
      foreach($registros as $info):
    ?>
  <p><b><?php echo $info->palabra;?>: </b><?php echo $info->significado; ?> </p>
    <?php
      endforeach
    ?>
</div>
</div>
<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
     
</body>


</html> 
