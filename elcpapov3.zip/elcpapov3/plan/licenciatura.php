<!DOCTYPE html>
<html lang="en">
  <head>
  <title>ELCEPAPO</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" type="text/css" href="estilo.css">
<link rel="stylesheet" type="text/css" href="navbar.css">

<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
</head>
 <body>
 
<?php
    require("navbar.php");
    ?>




<div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
  <!-- Overlay -->
  <div class="overlay"></div>

  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#bs-carousel" data-slide-to="0" class="active"></li>
    <li data-target="#bs-carousel" data-slide-to="1"></li>
    <li data-target="#bs-carousel" data-slide-to="2"></li>
  </ol>
  
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item slides active">
      <div class="slide-1"></div>
      <div class="hero">
        <hgroup>
            <h1>We are creative</h1>        
            <h3>Get start your next awesome project</h3>
        </hgroup>
        <button class="btn btn-hero btn-lg" role="button">See all features</button>
      </div>
    </div>
    <div class="item slides">
      <div class="slide-2"></div>
      <div class="hero">        
        <hgroup>
            <h1>We are smart</h1>        
            <h3>Get start your next awesome project</h3>
        </hgroup>       
        <button class="btn btn-hero btn-lg" role="button">See all features</button>
      </div>
    </div>
    <div class="item slides">
      <div class="slide-3"></div>
      <div class="hero">        
        <hgroup>
            <h1>We are amazing</h1>        
            <h3>Get start your next awesome project</h3>
        </hgroup>
        <button class="btn btn-hero btn-lg" role="button">See all features</button>
      </div>
    </div>
  </div> 
</div>



 <center>
    <div style="margin:0px auto;width:90%;text-align:center;padding:0px;background-color:#1C8C65;color:white;border:0px solid black;"> <h1> LICENCIATURAS </h1></div>
</center>

<div class="container" style="z-index:-1">

  <div class="row" style="z-index:-1 ">
    <h1>Carreras</h1>
        <div role="tabpanel" style="z-index:-1 ">
            <div class="col-sm-3"  >
                <ul class="nav nav-pills brand-pills nav-stacked" role="tablist" style="z-index:-1">
                    <li role="presentation" class="brand-nav active"><a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab"><h2>Inicio</h2></a></li>
                    <li role="presentation" class="brand-nav"><a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Ciencias Políticas y Administración Pública</a></li>
                    <li role="presentation" class="brand-nav"><a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Derecho Gubernamental</a></li>
                    <li role="presentation" class="brand-nav"><a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab">Gestión y Desarrollo Municipal</a></li>
                    <li role="presentation" class="brand-nav"><a href="#tab5" aria-controls="tab5" role="tab" data-toggle="tab">Seguridad Pública</a></li>
                    <li role="presentation" class="brand-nav"><a href="#tab6" aria-controls="tab6" role="tab" data-toggle="tab">Políticas Públicas</a></li>
                    <li role="presentation" class="brand-nav"><a href="#tab7" aria-controls="tab7" role="tab" data-toggle="tab">Pedagogía</a></li>
                    <li role="presentation" class="brand-nav"><a href="#tab8" aria-controls="tab8" role="tab" data-toggle="tab">Administración de Empresas</a></li>
                </ul>
            </div>
            <div class="col-sm-9" >
                <div class="tab-content"  >
                    <div role="tabpanel" class="tab-pane active" id="tab1" >





<!--modal de requisitos-->
<!-- Trigger the modal with a button -->
<center>
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">REQUISITOS</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Requisitos</h4>
        </div>
        <div class="modal-body">
         <p>• Original y 3 copias fotostáticas del acta de nacimiento.</p>
                <p> • Original y 3 copias fotostáticas del certificado de bachillerato (según sea el caso).</p>
                <p> • 3 copias fotostáticas de la CURP.</p>
                <p> • Para el caso de extranjeros, dos copias de la forma migratoria correspondiente.</p>
                <p> • 6 fotografías tamaño infantil.</p>
                <p> • Cubrir la cuota de inscripción y derechos respectivos.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
<!--boton-->

<a href="solicitudes/solicitud de inscripción.doc" ><button type="button" class="btn btn-info btn-lg" >SOLICITUD DE INSCRIPCIÓN</button></a>

</center>

<!--carrusel -->
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="imagenes/1.jpg"  style="width:100%;">
      </div>

      <div class="item">
        <img src="imagenes/3.jpg"  style="width:100%;">
      </div>
    
      <div class="item">
        <img src="imagenes/8.jpg"  style="width:80%;">
      </div>
    </div>

    
  </div>
       
                    </div>
                    <div role="tabpanel" class="tab-pane" id="tab2">
       <p><h1>Ciencias Políticas y Administración Pública</h1></p>
                           RVOE ES032/2013 • 11/11/2013 • SEV
       
<div class="contenedor">
    <center>
        <img id=2 onclick="window.open('plan/Ciencias Políticas y Administración Pública.pdf')" src="imagenes/planE.png">
    </center>
</div>

  

    <p> Objetivo: </p>

    <p>Formar especialistas en el área de las relaciones sociales y controlar las diferentes modalidades de la planeación administrativa, la toma de decisiones, considerando las diferentes implicaciones políticas inherentes a las formas de organización, comunicación y práctica administrativa, a las que se incorporará con sentido práctico, crítico y renovador.</p><br>

    <p>Asimismo conoce el marco jurídico normativo de la Administración Pública en los ámbitos Ejecutivo, Legislativo y Judicial, distinguiendo la importancia del sector paraestatal en México. Propone estrategias administrativas para armonizar las formas de organización del sector público federal, con las necesidades de una buena administración local. Relaciona la problemática municipal con el análisis del desarrollo regional y maneja las cuestiones técnicas y operacionales necesarias a su mejoramiento.</p>
    
<br>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="tab3">
                         <p><h1>Derecho Gubernamental</h1></p>
                           RVOE ES030/2004 • 22/04/2004 • SEV
       
<div class="contenedor">
    <center>
    <img onclick="window.open('plan/Derecho Gubernamental.pdf')" id=2 src="imagenes/planE.png">
    </center>
</div>

  

    <p> Objetivo: </p>

    <p>Coadyuvar en la formación de profesionistas en los asuntos jurídicos aplicados al Quehacer Público</p>
    
<br>

                    </div>
                    <div role="tabpanel" class="tab-pane" id="tab4">
                        <p>
                           <p><h1>Gestión y Desarrollo Municipal</h1></p>
                           RVOE ES136/2004 • 29/11/2004 • SEV
       
<div class="contenedor">
    <center>
    <img id=2 onclick="window.open('plan/Gestión y Desarrollo Municipal.pdf')"src="imagenes/planE.png">
    </center>
</div>

  

    <p> Objetivo: </p>

    <p>El Licenciado en Gestión y Desarrollo Municipal estará capacitado para desarrollarse al servicio de comunidad y gobiernos municipales, capaces de realizar la planeación y administración sustentable del ayuntamiento, sus recursos humanos, y financieros así como la promoción de inversiones y el desarrollo de proyectos productivos de la comunidad bajo altas normas de calidad, formado bajo los valores del desarrollo social con equidad que mejore las condiciones de vida de la población y la sustentabilidad.</p>
    
<br> 
                        </p>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="tab5">
                        <p>
                           <p><h1>Seguridad Pública</h1></p>
                           RVOE ES031 /2013 • 11 /11 / 2013 • SEV
       
<div class="contenedor">
    <center>
    <img id=2 onclick="window.open('plan/Seguridad Pública.pdf')" src="imagenes/planE.png">
    </center>
</div>

  

    <p> Objetivo: </p>

    <p>Formar especialistas en el ámbito de seguridad pública con una visión integral de derechos humanos, ética pública ciudadana con capacidad analítica y crítica para la elaboración y operación de programas de atención a las necesidades comunitarias en materia de seguridad pública, con capacidad de diseñar alternativas de intervención en problemas de seguridad pública tanto a nivel regional, nacional e internacional.</p>
    
<br>  
                        </p>
                    </div>


                    <div role="tabpanel" class="tab-pane" id="tab6">
                        <p>
                            <p><h1>Políticas Públicas</h1></p>
                           RVOE ES141/2004 • 29/11/2004 • SEV
       
<div class="contenedor">
    <center>
    <img id=2 onclick="window.open('plan/Políticas Públicas.pdf')" src="imagenes/planE.png">
    </center>
</div>

  

    <p> Objetivo: </p>

    <p>Contribuir a la formación de profesionistas de un alto nivel en el diseño y gestión de las políticas públicas para alcanzar una mayor eficiencia en las acciones del Estado.</p>
 
<p>El egresado de este programa poseerá la habilidad suficiente para identificar los temas y preocupaciones prioritarias de la población, del país y de los sectores productivos.</p>
 
<p>Tendrá los suficientes elementos para participar en la formulación de programas gubernamentales, así como en su implementación y evaluación.</p>
 
<p>Así mismo, será capaz de interactuar con especialistas de otras disciplinas y con la propia ciudadanía para la elaboración de estrategias que aborden de manera integral la agenda de gobierno y de las instituciones sociales.</p>
    
<br>  
                        </p>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="tab7">
                        <p>
                          <p><h1>Pedagogía</h1></p>
                           RVOE ES053/2014 • 19/12/2014 • SEV
       
<div class="contenedor">
    <center>
    <img id=2 onclick="window.open('plan/Pedagogía.pdf')" src="imagenes/planE.png">
    </center>
</div>
<p> Objetivo: </p>
  
<br>    
                        </p>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="tab8">
                        <p>
                           <p><h1>Administración de Empresas</h1></p>
                           RVOE ES054/2014 • 19/12/2014
       
<div class="contenedor">
    <center>
    <img id=2 onclick="window.open('plan/Administración de Empresas.pdf')" src="imagenes/planE.png">
    </center>
</div>

  

    <p> Objetivo: </p>

    
<br>   
                        </p>
                    </div>




                </div>
            </div>
        </div>
  </div>
</div>
   
  </body>
</html>