 <footer>
      <div class="panel-footer" style="background: #07a004; color: white;">
       <div class="row">
        <div class="col-sm-4">
          <p>
          <div class="col-sm-12">
          <img src="imagenes/LOGOFOOTER.png" class="img-responsive">
          </div>
          </p>
        </div>
        <div class="col-sm-2">
          <p>
            <label>OFERTA EDUCATIVA:</label>
            <ul>
              <li>Licenciaturas</li>
              <li>Maestrías</li>
              <li>Doctorados</li>
            </ul>
          </p>
        </div>

        <div class="col-sm-6">
          <div class="col-sm-2"><br><img src="imagenes/ubicacion.png" class="img-responsive"></div>
          <div class="col-sm-3">Direcci&oacute;n: <br>Alfonso Flores Bello 24, Zona Centro, Centro, 91000 Xalapa Enríquez, Ver.</div>
          <div class="col-sm-2"><br><img src="imagenes/telefono.png" class="img-responsive"></div>
          <div class="col-sm-3"><br><br>Teléfono:<br> 01 228 818 77</div>
        </div>
      </div> 
      
      </div>
  </footer>  