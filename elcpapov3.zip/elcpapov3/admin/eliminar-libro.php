<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script src="../css/sweetalert-dev.js"></script>
</head>
<body>

<?php 

include("../conexion.php");


$id_documento=$_REQUEST['id_documento'];

$eliminarLibro="DELETE FROM libros WHERE id_documento='$id_documento'";
$resultadoEliminar=$mysqli->query($eliminarLibro);

if ($resultadoEliminar>0) {
	echo "<script>
           swal({
  title: 'Eliminado',
  text: 'El libro ha sido eliminado!',
  type: 'success',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.location='administrar-libros.php';
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}else{
	echo "<script>
           swal({
  title: 'Error',
  text: 'Ocurrio un error. Intentelo de nuevo',
  type: 'error',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.location='administrar-libros.php';
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}

 ?>
</body>
</html>