
<!DOCTYPE html>
<html>
<head>
	<title>Registro</title>

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
        <script src="../js/jquery-latest.js"></script>    
        <link rel="stylesheet" type="text/css" href="../css/reset.css">
        <link rel="stylesheet" type="text/css" href="../css/navbar.css">   
        <script type="text/javascript" src="../js/jquery.min.js"></script>
        <script type="text/javascript" src="../js/menuresponsive.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
        <script src="../css/sweetalert.min.js"></script>
  <script>
            function validarNombre()
            {
                valor = document.getElementById("nombre").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Falta Llenar Nombre');
                    return false;
                } else { return true;}
            }

            function validarEdad()
            {
                valor = document.getElementById("edad").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Faltar Llenar Edad');
                    return false;
                } else { return true;}
            }

            function validarDireccion()
            {
                valor = document.getElementById("direccion").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Faltar Llenar Dirección');
                    return false;
                } else { return true;}
            }

            function validarEmail()
            {
                valor = document.getElementById("correo").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Faltar Llenar Correo Electrónico');
                    return false;
                } else { return true;}
            }
            
            function validarUsuario()
            {
                valor = document.getElementById("usuario").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Falta Llenar Usuario');
                    return false;
                } else { return true;}
            }
            
            function validarPassword()
            {
                valor = document.getElementById("password").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Falta Llenar Password');
                    return false;
                    } else { 
                    valor2 = document.getElementById("con_password").value;
                    
                    if(valor == valor2) { return true; }
                    else { alert('Las contraseña no coinciden'); return false;}
                }
            }
            
            
            function validar()
            {
                if(validarNombre() && validarUsuario() && validarPassword() && validarEdad() && validarDireccion() && validarEmail())
                {
                    document.registro.submit();
                }
            }
            
        </script>
</head>
<body>
<?php 
	include("navbarAdmin.php");
 ?>

<!-- formulario --> 
<div class="container">
<div class="titulo" style="border-radius: 0px 0px 0px 0px;"> 
                <center><h2><strong>Agregar nuevo usuario</strong></h2></center>
            </div>
    <div class="row col-md-4 col-md-offset-1">
        <br>
        <div class="panel panel-default" style="border-radius: 15px 15px;">
        
            <div class="panel-body">    
            <form id="registro" name="registro" action="registrar.php" method="POST" > 
                <div><label for="nombre" class="control-label">Nombre:</label>
                <input id="nombre" name="nombre" type="text" class="form-control" placeholder="Nombre"></div>
                <br />

                <div><label for="apellido" class="control-label">Apellido:</label>
                <input id="apellido" name="apellido" type="text" class="form-control" placeholder="Apellido"></div>
                <br />
                
                <div><label for="usuario" class="control-label">Usuario:</label>
                <input id="usuario" name="usuario" type="text" class="form-control" placeholder="Usuario"></div>
                <br />
                
                <div><label for="password" class="control-label">Password:</label>
                <input id="password" name="password" type="password" class="form-control" placeholder="Password"></div>
                <br />
                <div><label for="con_password" class="control-label">Confirmar Password:</label>
                <input id="con_password" name="con_password" type="password" class="form-control" placeholder="Password"></div>
                <br />
            </div>
        </div>
    </div>
    <div class="row col-md-4 col-md-offset-1">
        <br>
        <div class="panel panel-default" style="border-radius: 15px 15px;">
        
            <div class="panel-body">
                

                <div><label for="edad" class="control-label">Edad</label>
                <input type="text" name="edad" id="edad" class="form-control" placeholder="Edad"></div>
                <br>

                <div><label for="direccion" class="control-label">Dirección</label>
                <input type="text" name="direccion" id="direccion" class="form-control" placeholder="Dirección"></div>
                <br>

                <div><label for="correo" class="control-label">Correo Electrónico</label>
                <input type="email" name="correo" id="correo" class="form-control" placeholder="Correo Electrónico"></div>
                <br>

                <div><label for="telefono" class="control-label">Telefono</label>
                <input type="text" name="telefono" id="telefono" class="form-control" placeholder="Correo Electrónico"></div>
                <br>
                <div><input class="btn btn-lg btn-primary" name="registar" type="button" value="Registrar" onClick="validar();"></div> 
                </form>
            </div>
        </div>
    </div>
</div>
        
        <?php if($bandera) { ?>
            <script type="text/javascript">
                alert("Registrado");     
            </script>
            
            <?php }else{ ?>
            <br />
            <div style = "font-size:16px; color:#cc0000;"><?php echo isset($error) ? utf8_decode($error) : '' ; ?></div>
            
        <?php } ?>

<?php include("footer.php"); ?>
</body>
</html>