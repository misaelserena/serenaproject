<?php

session_start();
$user = $_SESSION['usuario'];
if(isset($_SESSION['usuario'])){
    if($_SESSION['tipo_usuario'] == 1){
        
    }else{
        header("Location: ../user/user.php");
    }
}else{
    header("Location: ../index.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Administrar Dccionario</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
		<script src="../js/jquery-latest.js"></script>    
		<link rel="stylesheet" type="text/css" href="../css/reset.css">
		<link rel="stylesheet" type="text/css" href="../css/navbar.css">   
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../js/menuresponsive.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
        <script src="../css/sweetalert.min.js"></script>

</head>
<body>
<?php include("navbarAdmin.php"); ?>

<?php
    $sqlDiccionario="SELECT * FROM diccionario ORDER BY estado DESC, palabra ASC";
    $conexion=$base->query($sqlDiccionario);
    $resultadoDiccionario=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>

    <div class="container">
        <div class="table-responsive">
            <div class="titulo" style="border-radius: 0px 0px 0px 0px;"> 
                <center><h2><strong>Administraci&oacute;n del diccionario</strong></h2></center>
            </div>
            <table class="table table-hover table-bordered" style="background: white;">
                <thead>
                    <th>ID</th>
                    <th>Palabra</th>
                    <th>Siginificado</th>
                    <th>Estado</th>
                    <th>Aprobar</th>
                    <th>Eliminar</th>
                </thead>
                <tbody>
                <?php foreach ($resultadoDiccionario as $palabra): ?>
                    <tr>
                        <td><?php echo $palabra->idDiccionario; ?></td>
                        <td><?php echo $palabra->palabra; ?></td>
                        <td><?php echo $palabra->significado; ?></td>
                        <td><?php echo $palabra->estado; ?></td>
                        <td><a href="formulario-diccionario.php?idDiccionario=<?php echo $palabra->idDiccionario; ?>" class="btn btn-success" target="popup" onclick="window.open('', 'popup', 'width = 480, height = 580')">Aprobar</a></td>
                        <td><a href="eliminar-diccionario.php?idDiccionario=<?php echo $palabra->idDiccionario; ?>" class="btn btn-danger">Eliminar</a></td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div> 
    </body>
    </html>