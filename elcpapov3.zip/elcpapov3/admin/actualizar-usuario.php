<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script src="../css/sweetalert-dev.js"></script>
</head>
<body>

<?php 

include("../conexion.php");


$idUsuario=$_POST['idUsuario'];
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$direccion=$_POST['direccion'];
$telefono=$_POST['telefono'];
$email=$_POST['email'];

$actualizarLibro="UPDATE personal SET id='$idUsuario', name='$nombre', lastname='$apellido', address='$direccion', phone='$telefono', email='$email' WHERE id='$idUsuario'";
$resultadoActualizar=$mysqli->query($actualizarLibro);

if ($resultadoActualizar>0) {
	echo "<script>
           swal({
  title: 'Cambios Guardados',
  text: 'El perfil fue actualizado!',
  type: 'success',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.close();
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}else{
	echo "<script>
           swal({
  title: 'Error',
  text: 'Ocurrio un error. Intentelo de nuevo',
  type: 'error',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.close();
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}

 ?>
</body>
</html>