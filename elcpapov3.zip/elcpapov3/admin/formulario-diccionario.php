<?php 
$idDiccionario=$_REQUEST['idDiccionario'];
 ?>

 <?php
 include("cn.php");
    $sqlDiccionario="SELECT * FROM diccionario WHERE idDiccionario='$idDiccionario'";
    $conexion=$base->query($sqlDiccionario);
    $resultadoDiccionario=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
<!DOCTYPE html>
<html>
<head>
	<title>Aprobar Palabra</title>

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
		<script src="../js/jquery-latest.js"></script>    
		<link rel="stylesheet" type="text/css" href="../css/reset.css">
		<link rel="stylesheet" type="text/css" href="../css/navbar.css">   
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../js/menuresponsive.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css"> 
</head>
<body>
<br>
<div class="container">
	<div class="panel panel-default">
	<div class="titulo" style="border-radius: 0px 0px 0px 0px; color: black;">
                <center><h2><strong>Aprobar definici&oacute;n</strong></h2></center>
            </div>
		<div class="panel-body">
			<form action="actualizar-diccionario.php" method="post">
			<?php foreach ($resultadoDiccionario as $diccionario): ?>
                   
                <input style="display: none;" type="text" name="idDiccionario" value="<?php echo $diccionario->idDiccionario ?>">       
				
				<div class="form-group">
					<label class="label-control">Palabra</label>
					<input type="text" name="palabra" class="form-control" value="<?php echo $diccionario->palabra ?>">
				</div>
				<div class="form-group">
					<label class="label-control">Significado</label>
					<textarea class="form-control" style="height: 200px;" name="significado"><?php echo $diccionario->significado ?></textarea>
				</div>
				<?php endforeach ?>
				<div class="form-group">
					<label class="label-control">¿Desea aprobar la definici&oacute;n?</label>
					<select class="form-control" name="aprobar">
						<option class="form-control"></option>
						<option class="form-control" value="aprobado">Aprobar</option>
						<option class="form-control" value="no aprobado">No aprobar</option>
					</select>
				</div>
				<div class="form-group">
					<input type="submit" name="actualizar" value="Guardar Cambios" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
</div>

</body>
</html>