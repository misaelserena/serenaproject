<?php

session_start();
$user = $_SESSION['usuario'];
if(isset($_SESSION['usuario'])){
    if($_SESSION['tipo_usuario'] == 1){
        
    }else{
        header("Location: ../alumno/home.php");
    }
}else{
    header("Location: ../index.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Administrador</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
		<script src="../js/jquery-latest.js"></script>    
		<link rel="stylesheet" type="text/css" href="../css/reset.css">
		<link rel="stylesheet" type="text/css" href="../css/navbar.css">   
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../js/menuresponsive.js"></script>

</head>
<body>
<?php include("navbarAdmin.php"); ?>

<div class="container">
    

     <div class="titulo" style="border-radius: 0px 0px 0px 0px;">
         <center><h2><strong>Bienvenido: <?php echo $user; ?></strong></h2></center>
     </div>


    <div class="w3-row-padding w3-white">

        <div class="col-sm-3">
          <h2><strong>Administrar calificaciones</strong></h2>
          <p>En esta secci&oacute;n podr&aacute; gestionar las calificaciones de los alumnos. <br>
          As&iacute; como eliminar usuarios, que ya no deban estar en el sistema.</p>
          <p><a href="administrar-calificaciones.php" class="btn btn-success">Ingresar</a></p>
          <hr>
        </div>

        <div class="col-sm-3">
          <h2><strong>Administrar Usuarios</strong></h2>
          <p>En esta secci&oacute;n podr&aacute; modificar datos personales de los usuarios registrados en el sistema. <br>
          As&iacute; como eliminar usuarios, que ya no deban estar en el sistema.</p>
          <p><a href="administrar-usuarios.php" class="btn btn-success">Ingresar</a></p>
          <hr>
        </div>

        <div class="col-sm-3">
          <h2><strong>Administrar Libros de la Biblioteca Virtual</strong></h2>
          <p>En esta secci&oacute;n podr&aacute; aprobar aquellos libros que cumplan con los requisitos necesarios para ser publicados <br> en nuestra biblioteca virtual, la c&uacute;al esta disponible para todos nuestros alumnos.</p> 
          <p><a href="administrar-libros.php" class="btn btn-success">Ingresar</a></p>
          <hr>
        </div>

        <div class="col-sm-3">
          <h2><strong>Administrar Diccionario Virtual</strong></h2>
          <p>En esta secci&oacute;n podr&aacute; aprobar las palabras que el p&uacute;blico agregue a nuestro <br> diccionario virtual</p>
          <p><a href="administrar-diccionario.php" class="btn btn-success">Ingresar</a></p></p>
          <hr>
        </div>

    </div>

</div>    
</body>
</html>