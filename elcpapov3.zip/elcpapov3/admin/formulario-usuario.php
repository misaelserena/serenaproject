<?php 
  include("cn.php");
  $idUsuario=$_REQUEST['idUsuario'];

    $sqlUsuarios="SELECT * FROM usuarios, personal,tiposusuario WHERE usuarios.Personal_idPersonal=personal.id and usuarios.TiposUsuario_idTipo=tiposusuario.idTipo and idUsuario=$idUsuario;";
    $conexion=$base->query($sqlUsuarios);
    $resultadoUsuarios=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
<!DOCTYPE html>
<html>
<head>
    <title>Editar Usuario</title>

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
        <script src="../js/jquery-latest.js"></script>    
        <link rel="stylesheet" type="text/css" href="../css/reset.css">
        <link rel="stylesheet" type="text/css" href="../css/navbar.css">   
        <script type="text/javascript" src="../js/jquery.min.js"></script>
        <script type="text/javascript" src="../js/menuresponsive.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css"> 
</head>
<body>
<br>
<div class="container">
    <div class="panel panel-default">
        <div class="titulo" style="border-radius: 0px 0px 0px 0px; color: black;">
            <center><h2><strong>Datos del Usuario</strong></h2></center>
        </div>
        <div class="panel-body">
            <form method="post" action="actualizar-usuario.php">
            <?php foreach ($resultadoUsuarios as $usuario): ?>                       
                <div class="form-group">
                    <label class="label-control">ID</label>
                    <input type="text" name="idUsuario" class="form-control" value="<?php echo $usuario->idUsuario; ?>">
                </div>

                <div class="form-group">
                    <label class="label-control">Usuario</label>
                    <input type="text" name="usuario" class="form-control" value="<?php echo $usuario->usuario; ?>">
                </div>

                <div class="form-group">
                    <label class="label-control">Nombre</label>
                    <input type="text" name="nombre" class="form-control" value="<?php echo $usuario->name; ?>">
                </div>

                <div class="form-group">
                    <label class="label-control">Apellido</label>
                    <input type="text" name="apellido" class="form-control" value="<?php echo $usuario->lastname; ?>">
                </div>

                <div class="form-group">
                    <label class="label-control">Direcci&oacute;</label>
                    <input type="text" name="direccion" class="form-control" value="<?php echo $usuario->address; ?>">
                </div>

                <div class="form-group">
                    <label class="label-control">Tel&eacute;fono</label>
                    <input type="text" name="telefono" class="form-control" value="<?php echo $usuario->phone; ?>">
                </div>

                <div class="form-group">
                    <label class="label-control">Email</label>
                    <input type="text" name="email" class="form-control" value="<?php echo $usuario->email; ?>">
                </div>

                <div class="form-group">
                    <label class="label-control">Tipo de usuario</label>
                    <input type="text" name="tipo" class="form-control" value="<?php echo $usuario->tipo; ?>">
                </div>

                <div class="form-group">
                    <input type="submit" name="guardar" value="Guardar" class="btn btn-primary">
                </div>
            <?php endforeach ?>
            </form>
        </div>
    </div>