<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script src="../css/sweetalert-dev.js"></script>
</head>
<body>
</body>
</html>
<?php
    
    //session_start();
    require '../conexion.php';
    
    /*if(!isset($_SESSION["id_usuario"])){
    header("Location: index.php");
    }
    */
    $sql = "SELECT idTipo, tipo FROM TiposUsuario";
    $result=$mysqli->query($sql);
    
    $bandera = false;
    
    if(!empty($_POST))
    {
        $nombre = mysqli_real_escape_string($mysqli,$_POST['nombre']);
        $usuario = mysqli_real_escape_string($mysqli,$_POST['usuario']);
        $password = mysqli_real_escape_string($mysqli,$_POST['password']);
        $tipo_usuario = 2;
        $apellido = $_POST['apellido'];
        $direccion = $_POST['direccion'];
        $email = $_POST['correo'];
        $telefono = $_POST['telefono'];

        $sha1_pass = sha1($password);

        
        date_default_timezone_set('America/Mexico_City');
                        $fecha= date ("Y-m-d");
                        
                        $time = time();
        $hora = date("Y-m-d H:i:s", $time);
        
        
        
        $error = ''; 
        
        $sqlUser = "SELECT idUsuario FROM usuarios WHERE usuario = '$usuario'";
        $resultUser=$mysqli->query($sqlUser);
        $rows = $resultUser->num_rows;
        
        if($rows > 0) {
            $error = "El usuario ya existe";
            } else {
            
            $sqlPerson = "INSERT INTO personal(name,lastname,email,address,phone,created_at) VALUES ('$nombre','$apellido','$email','$direccion','$telefono','$hora')";
            $resultPerson=$mysqli->query($sqlPerson);
            $idPersona = $mysqli->insert_id;
            
            $sqlUsuario = "INSERT INTO usuarios (usuario, password, Personal_idPersonal, TiposUsuario_idTipo) VALUES('$usuario','$sha1_pass','$idPersona','$tipo_usuario')";
            $resultUsuario = $mysqli->query($sqlUsuario);
            
            if($resultUsuario>0)
            {
                echo "<script>
                           swal({
                                  title: 'Usuario Registrado',
                                  text: 'El usuario ha sido registrado. Ya puedes iniciar sesion',
                                  type: 'success',
                                  confirmButtonColor: '#DD6B55',
                                  confirmButtonText: 'Aceptar',
                                  closeOnConfirm: true
                                },
                                function(isConfirm){
                                  if (isConfirm) {
                                    window.location.href='home.php';
                                  } else {
                                        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
                                  }
                                });
                          </script>";
            }
            else
            {
                echo "<script>
                           swal({
                              title: 'Error',
                              text: 'Ocurrio un error. Intentelo de nuevo',
                              type: 'error',
                              confirmButtonColor: '#DD6B55',
                              confirmButtonText: 'Aceptar',
                              closeOnConfirm: true
                            },
                            function(isConfirm){
                              if (isConfirm) {
                                window.history.back(-1);
                              } else {
                                    swal('Cancelled', 'Your imaginary file is safe :)', 'error');
                              }
                            });
                      </script>";
            }
            
        }
    }
    
?>
