<?php

session_start();
$user = $_SESSION['usuario'];
if(isset($_SESSION['usuario'])){
    if($_SESSION['tipo_usuario'] == 1){
        
    }else{
        header("Location: ../user/user.php");
    }
}else{
    header("Location: ../index.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Administrar Usuarios</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
		<script src="../js/jquery-latest.js"></script>    
		<link rel="stylesheet" type="text/css" href="../css/reset.css">
		<link rel="stylesheet" type="text/css" href="../css/navbar.css">   
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../js/menuresponsive.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
        <script src="../css/sweetalert.min.js"></script>

</head>
<body>
<?php include("navbarAdmin.php"); ?>

<?php
    $sqlUsuarios="SELECT * FROM usuarios, personal,tiposusuario WHERE usuarios.Personal_idPersonal=personal.id and usuarios.TiposUsuario_idTipo=tiposusuario.idTipo;";
    $conexion=$base->query($sqlUsuarios);
    $resultadoUsuarios=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>

    <div class="container">
    <button class="btn btn-lg btn-primary">Nuevo Usuario</button>
        <div class="table-responsive">
            <div class="titulo" style="border-radius: 0px 0px 0px 0px;"> 
                <center><h2><strong>Administraci&oacute;n de usuarios</strong></h2></center>
            </div>
            <table class="table table-hover table-bordered" style="background: white;">
                <thead>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Nombre</th>
                    <th>Direcci&oacute;n</th>
                    <th>Tel&eacute;fono</th>
                    <th>Email</th>
                    <th>Tipo de usuario</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </thead>
                <tbody>
                    <?php foreach ($resultadoUsuarios as $usuario): ?>
                    <tr>
                        <td><?php echo $usuario->idUsuario; ?></td>
                        <td><?php echo $usuario->usuario; ?></td>
                        <td><?php echo $usuario->name." ".$usuario->lastname; ?></td>
                        <td><?php echo $usuario->address; ?></td>
                        <td><?php echo $usuario->phone; ?></td>
                        <td><?php echo $usuario->email; ?></td>
                        <td><?php echo $usuario->tipo; ?></td>
                        <td><a href="formulario-usuario.php?idUsuario=<?php echo $usuario->idUsuario; ?>" class="btn btn-success" target="popup" onclick="window.open('', 'popup', 'width = 480, height = 580')">Editar</a></td>
                        <td><a href="eliminar-usuario.php?idUsuario=<?php echo $usuario->idUsuario; ?>" class="btn btn-danger">Eliminar</a></td>
                    <?php endforeach ?>    
                    </tr>
                </tbody>
            </table>
        </div>
    </div>    

</body>
</html>