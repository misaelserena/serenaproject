<?php

session_start();
$user = $_SESSION['usuario'];
if(isset($_SESSION['usuario'])){
    if($_SESSION['tipo_usuario'] == 1){
        
    }else{
        header("Location: ../user/user.php");
    }
}else{
    header("Location: ../index.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Administrar Libros</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
		<script src="../js/jquery-latest.js"></script>   
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css"> 
		<link rel="stylesheet" type="text/css" href="../css/reset.css">
		<link rel="stylesheet" type="text/css" href="../css/navbar.css">   
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../js/menuresponsive.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
        <script src="../css/sweetalert.min.js"></script>

</head>
<body>
<?php include("navbarAdmin.php"); ?>

<?php
    $sqlLibros="SELECT * FROM libros order by id_documento;";
    $conexion=$base->query($sqlLibros);
    $resultadoLibros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
    
    <div class="container">
        <div class="table-responsive">
            <div class="titulo" style="border-radius: 0px 0px 0px 0px;">
                <center><h2><strong>Administraci&oacute;n de libros</strong></h2></center>
            </div>
            <table class="table table-hover table-bordered" style="background: white;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>T&iacute;tulo</th>
                        <th>Categor&iacute;a</th>
                        <th>Tipo</th>
                        <th>Nombre del archivo</th>
                        <th>Estado</th>
                        <th>Ver Libro</th>
                        <th>Aprobar Libro</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($resultadoLibros as $libro): ?>
                    <tr>
                        <td><?php echo $libro->id_documento ?></td>
                        <td><?php echo $libro->titulo ?></td>
                        <td><?php echo $libro->categoria ?></td>
                        <td><?php echo $libro->tipo ?></td>
                        <td><?php echo $libro->nombre_archivo ?></td>
                        <td><?php echo $libro->estado ?></td>
                        <td><a href="../user/archivos/<?php echo $libro->nombre_archivo; ?>" class="btn btn-info" target="blank">Ver</a></td>
                        <td><a href="formularioLibros.php?id_documento=<?php echo $libro->id_documento; ?>" class="btn btn-success" target="popup" onclick="window.open('', 'popup', 'width = 480, height = 580')">Aprobar</a></td>
                        <td><a href="eliminar-libro.php?id_documento=<?php echo $libro->id_documento; ?>" class="btn btn-danger">Eliminar</a></td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>