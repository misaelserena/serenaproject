<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script src="../css/sweetalert-dev.js"></script>
</head>
<body>

<?php 

include("../conexion.php");


$id_documento=$_POST['id_documento'];
$titulo=$_POST['titulo'];
$categoria=$_POST['categoria'];
$tipo=$_POST['tipo'];
$nombre_archivo=$_POST['nombre_archivo'];
$estado=$_POST['aprobar'];

$actualizarLibro="UPDATE libros SET id_documento='$id_documento', titulo='$titulo', categoria='$categoria', estado='$estado' WHERE id_documento='$id_documento'";
$resultadoActualizar=$mysqli->query($actualizarLibro);

if ($resultadoActualizar>0) {
	echo "<script>
           swal({
  title: 'Cambios Guardados',
  text: 'El estado del libro ha sido modificado!',
  type: 'success',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.close();
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}else{
	echo "<script>
           swal({
  title: 'Error',
  text: 'Ocurrio un error. Intentelo de nuevo',
  type: 'error',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.location='administrar-libros.php';
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}

 ?>
</body>
</html>