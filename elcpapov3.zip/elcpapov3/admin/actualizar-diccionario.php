<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script src="../css/sweetalert-dev.js"></script>
</head>
<body>

<?php 

include("../conexion.php");

$idDiccionario=$_POST['idDiccionario'];
$palabra=$_POST['palabra'];
$significado=$_POST['significado'];
$estado=$_POST['aprobar'];

$actualizarDiccionario="UPDATE diccionario SET idDiccionario='$idDiccionario', palabra='$palabra', significado='$significado', estado='$estado' WHERE idDiccionario='$idDiccionario'";
$resultadoActualizar=$mysqli->query($actualizarDiccionario);

if ($resultadoActualizar>0) {
	echo "<script>
           swal({
  title: 'Cambios Guardados',
  text: 'El estado de $palabra ha sido modificado!',
  type: 'success',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.close();
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}else{
	echo "<script>
           swal({
  title: 'Error',
  text: 'Ocurrio un error. Intentelo de nuevo',
  type: 'error',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.close();
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}

 ?>
</body>
</html>