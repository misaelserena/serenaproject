<?php include("cn.php"); ?>
<header class="newcontainer">   
<div><img src="../imagenes/headerprueba.png" class="img-responsive" width="100%"></div>      
    <nav class="navbar">
        <div class="newcontainer-fluid">                
            <div class="newnavbar-header">
                 <button type="button" class="newnavbar-toggle" data-toggle="collapse" data-target="#menu">                 
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                 </button>
                 <a class="newnavbar-brand" href="../index.php"><img src="../imagenes/icono.png" class="img-responsive"> </a>
            </div>
             
            <div class="collapse newnavbar-collapse" id="menu">
                 <ul class="newnavbar-nav">
                        <li class="newdropdown"><a href="home.php">Administrar</a>
                        <ul class="newdropdown-menu">
                                <li><a href="administrar-usuarios.php">Usuarios</a></li>
                                <li><a href="administrar-libros.php">Libros</a></li>
                                <li><a href="administrar-diccionario.php">Diccionario</a></li>
                                <li><a href="registro-usuario.php">Nuevo Usuario</a></li>
                          </ul>
                        </li>
                        </li>
                        <li style="float: right;"><a href="cerrarsesion.php">Cerrar Sesi&oacute;n</a></li>

                 </ul>                
            </div>
        </div>
    </nav>      
</header>