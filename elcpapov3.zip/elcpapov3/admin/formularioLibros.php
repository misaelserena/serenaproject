<?php 
$id_documento=$_REQUEST['id_documento'];
 ?>

 <?php
 include("cn.php");
    $sqlLibros="SELECT * FROM libros WHERE id_documento='$id_documento'";
    $conexion=$base->query($sqlLibros);
    $resultadoLibros=$conexion->fetchAll(PDO::FETCH_OBJ);
    ?>
<!DOCTYPE html>
<html>
<head>
	<title>Aprobar</title>

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
		<script src="../js/jquery-latest.js"></script>    
		<link rel="stylesheet" type="text/css" href="../css/reset.css">
		<link rel="stylesheet" type="text/css" href="../css/navbar.css">   
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../js/menuresponsive.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/estilosTexto.css"> 
</head>
<body>
<br>
<div class="container">
	<div class="panel panel-default">
	<div class="titulo" style="border-radius: 0px 0px 0px 0px; color: black;">
                <center><h2><strong>Aprobar libro</strong></h2></center>
            </div>
		<div class="panel-body">
			<form action="actualizar-libro.php" method="post">
			<?php foreach ($resultadoLibros as $libro): ?>
                   
                <input style="display: none;" type="text" name="id_documento" value="<?php echo $libro->id_documento ?>">       
				
				<div class="form-group">
					<label class="label-control">T&iacute;tulo</label>
					<input type="text" name="titulo" class="form-control" value="<?php echo $libro->titulo ?>">
				</div>
				<div class="form-group">
					<label class="label-control">Categor&iacute;a</label>
					<input type="text" name="categoria" class="form-control" value="<?php echo $libro->categoria ?>">
				</div>
				<div class="form-group">
					<label class="label-control">Tipo</label>
					<input type="text" name="tipo" class="form-control" value="<?php echo $libro->tipo ?>">
				</div>
				<div class="form-group">
					<label class="label-control">Nombre del archivo</label>
					<input type="text" name="nombre_archivo" class="form-control" value="<?php echo $libro->nombre_archivo ?>">
				</div>
			<?php endforeach ?>
				<div class="form-group">
					<label class="label-control">¿Desea aprobar el libro?</label>
					<select class="form-control" name="aprobar">
						<option class="form-control"></option>
						<option class="form-control" value="aprobado">Aprobar</option>
						<option class="form-control" value="no aprobado">No aprobar</option>
					</select>
				</div>
				<div class="form-group">
					<input type="submit" name="actualizar" value="Guardar Cambios" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
</div>

</body>
</html>