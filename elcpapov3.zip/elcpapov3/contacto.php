<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Contacto</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/bootstrap.min.js"></script>
	
</head>

<body>

	<?php
    include("navbar.php");
    ?>

	<center>
		<div class="principal">
			<div class="titulo">
				<h1 style="font-family: Arial;">Contacto</h1>
			</div>
					

				<form action="contacto_submit" method="get" accept-charst="utf-8" style="font-family: Arial; font-size:18px; ">
					<br><br>
		  			<input class="textbox" type="text" name="nombre" placeholder="Nombre Completo"><br><br>
		  			
		  			<input class="textbox" type="email" name="correo" placeholder="Inserte email"><br><br>
		  			
		  			<input class="textbox" type="email" name="correo" placeholder="Asunto"><br><br>
		  			
		  			<textarea class="textbox" rows="4" cols="50" name="comentario" placeholder="Inserte Texto"></textarea>
		  			<br><br>
					<input type="submit" value="Enviar" name="enviar" class="boton">
				</form>
		</div>
	</center>
</body>
<?php 
   include("footer.php") 
   ?>
</html>