<!DOCTYPE html>

<html>
	<head>
		<title>ELCPAPO</title>
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/estilosSlide.css">
        <link rel="stylesheet" type="text/css" href="css/w3.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">

        <script src="js/bootstrap.min.js"></script>
<!-- Start of Async Drift Code -->
          <script>
            !function() {
              var t;
              if (t = window.driftt = window.drift = window.driftt || [], !t.init) return t.invoked ? void (window.console && console.error && console.error("Drift snippet included twice.")) : (t.invoked = !0, 
              t.methods = [ "identify", "config", "track", "reset", "debug", "show", "ping", "page", "hide", "off", "on" ], 
              t.factory = function(e) {
                return function() {
                  var n;
                  return n = Array.prototype.slice.call(arguments), n.unshift(e), t.push(n), t;
                };
              }, t.methods.forEach(function(e) {
                t[e] = t.factory(e);
              }), t.load = function(t) {
                var e, n, o, i;
                e = 3e5, i = Math.ceil(new Date() / e) * e, o = document.createElement("script"), 
                o.type = "text/javascript", o.async = !0, o.crossorigin = "anonymous", o.src = "https://js.driftt.com/include/" + i + "/" + t + ".js", 
                n = document.getElementsByTagName("script")[0], n.parentNode.insertBefore(o, n);
              });
            }();
            drift.SNIPPET_VERSION = '0.3.1';
            drift.load('9gafthbgub9u');
          </script>
<!-- End of Async Drift Code -->
        <style>
        .city {
           float: left;
           margin: 10px;
           padding: 10px;
           max-width: 1200px;
           width: 90%;
           height: 300px;
           border: 1px solid black;
        }   
        </style>
    </head>

    <body>

    
        <?php
        include("navbar.php");
        ?>

<div style="width: 100%; margin: auto;">
   <!-- Full Page Image Background Carousel Header -->
    <center><header id="myCarousel" class="carousel slide" style="width: 95%">
        <!-- indicadores... agregar uno en caso de ser necesario -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
        </ol>


        <!-- INICIO SLIDE -->
        <!-- la imagen debe tener un tamaño de 1285 x 564 px -->
        <div class="carousel-inner">
        <!-- INICIO primera imagen -->
          <div class="item active">
            <img src="imagenes/slide1.jpg" alt="..." style="width:100%">
              <div class="carousel-caption">
              </div>
          </div>
        <!-- FIN primera imagen -->

        <!-- INICIO SEGUNDA imagen -->
          <div class="item" >
            <img src="imagenes/slide2.jpg" alt="..." style="width:100%">
              <div class="carousel-caption">
              </div>
          </div> 
         <!-- FIN SEGUNDA imagen -->

         <!-- INICIO TERCERA imagen -->
          <div class="item" >
            <img src="imagenes/slide3.jpg" alt="..." style="width:100%">
              <div class="carousel-caption">
              </div>
          </div> 
         <!-- FIN TERCERA imagen -->

         <!-- INICIO CUARTA imagen -->
          <div class="item" >
            <img src="imagenes/slide4.jpg" alt="..." style="width:100%">
              <div class="carousel-caption">
              </div>
          </div> 
         <!-- FIN CUARTA imagen -->

         <!-- INICIO QUINTA imagen -->
          <div class="item" >
            <img src="imagenes/slide5.jpg" alt="..." style="width:100%">
              <div class="carousel-caption">
              </div>
          </div> 
         <!-- FIN QUINTA imagen -->
        </div>
        <!-- FIN SLIDE -->

        <!-- INICIO CONTROLERS -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
        <!-- FIN CONTROLERS -->
</div>
<br><br>

<!-- INICIO BLOQUE IMAGENES -->
<!-- SOLO HABRA DOS IMAGENES EN CADA FILA... la imagen debe tener un tamaño aproximado de 576 x 270 px, o a escala... -->
<div class="w3-row-padding" style="max-width: 1200px; width: 92%; margin: auto;">
  <!-- INICIO FILA  -->
  <!-- PRIMERA IMAGEN -->
  <div class="w3-half">
  <img src="imagenes/primera.jpg" style="width:100%" class="img-responsive"><br>
  <p style="color: #fff; font-weight: bold;">SOLO HABRA DOS IMAGENES EN CADA FILA... la imagen debe tener un tamaño aproximado de 576 x 270 px, o a escala</p>
  </div>
  <!-- SEGUNDA IMAGEN -->
  <div class="w3-half">
  <img src="imagenes/segunda.jpg" style="width:100%" class="img-responsive"><br>
  <p style="color: #fff; font-weight: bold;">SOLO HABRA DOS IMAGENES EN CADA FILA... la imagen debe tener un tamaño aproximado de 576 x 270 px, o a escala</p>
  </div>
  <!-- tercea IMAGEN -->
  <div class="w3-half">
  <img src="imagenes/tercera.jpg" style="width:100%" class="img-responsive"><br>
  <p style="color: #fff; font-weight: bold;">SOLO HABRA DOS IMAGENES EN CADA FILA... la imagen debe tener un tamaño aproximado de 576 x 270 px, o a escala</p>
  </div>
  <!-- cuarta IMAGEN -->
  <div class="w3-half">
  <img src="imagenes/cuarta.jpg" style="width:100%" class="img-responsive"><br>
  <p style="color: #fff; font-weight: bold;">SOLO HABRA DOS IMAGENES EN CADA FILA... la imagen debe tener un tamaño aproximado de 576 x 270 px, o a escala</p>
  </div>
  <!-- FIN FILA -->
  <!-- SI SE DESEA SEGUIR AGREGANDO IMAGENES HACIA ABAJO.. SE TIENE QUE AGREGAR EL SIGUIENTE CODIGO:
  <div class="w3-half">
  <img src="imagenes/NOMBREIMAGEN.jpg" style="width:100%" class="img-responsive"><br>
  </div> 
  -->
</div>
<br><br>

</body>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <script>
      $('.carousel').carousel({
          interval: 5000 //changes the speed
      })
    </script>
  <br>


   <?php 
   include("footer.php") 
   ?>



</html>