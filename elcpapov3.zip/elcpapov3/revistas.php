<!DOCTYPE html>
<html>
<title>Revistas</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>+
<link rel="stylesheet" type="text/css" href="estilo.css">
<body>

<?php
    include("navbar.php");
    ?>

<div class="contenedor">
    <center>
        <img id=2 onclick="window.open('http://www.enlaceducativo.com')" src= "imagenes/enlace.jpg" alt="Los Tejos">
    </center>
</div>

<div class="contenedor">
    <center>
        <img id=2 onclick="window.open('http://www.quehacerpublico.com')" src= "imagenes/quehacer.jpg" alt="Los Tejos">
    </center>
</div>

<div class="container">
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Formato</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Estimada comunidad estudiantil y personal docente
los invitamos a participar en nuestras revistas electr&oacute;nicas:</h4>
          <OL>
          <LI>Los art&iacute;culos deben ser enviados al correo jrgf-universidades@hotmail.com</LI> 
          <LI> Deben ser art&iacute;culos in&eacute;ditos y originales.</LI> 
          <LI>  Debe indicar en documento aparte, en cu&aacute;l de los apartados de la revista se ubicar&iacute;a su art&iacute;culo:</LI> 
         
                <UL type = square > 
                <li>Tecnolog&iacute;as de la Informaci&oacute;n y la Comunicaci&oacute;n aplicadas a la educaci&oacute;n.</li>
                <li>Pol&iacute;ticas P&uacute;blicas Educativas.</li> 
                <li>Reforma del Estado y Modernizaci&oacute;n de la Administraci&oacute;n P&uacute;blica.</li> 
                <li>Finanzas P&uacute;blicas.</li>
                <li>Desarrollo Regional y Municipal.</li>
                <li>Pol&iacute;ticas P&uacute;blicas.</li>
                <li>Temas actuales de la Administraci&oacute;n P&uacute;blica.</li> 
                </UL>
        
            <li>Debe integrar, al inicio del art&iacute;culo, un resumen y tres palabras clave.</li> 
            <li>Debe indicar en documento aparte: Nombre completo del autor, domicilio, nacionalidad, tel&eacute;fono, correo electr&oacute;nico, grado y perfil acad&eacute;mico y adscripci&oacute;n institucional (en la revista s&oacute;lo se publicar&aacute;n el perfil acad&eacute;mico y la adscripci&oacute;n institucional. El autor deber&aacute; se&ntilde;alar si aprueba que se publique su correo electr&oacute;nico).</li>
            <li>Letra: Times New Roman, n&uacute;mero: 12, interlineado sencillo.</li>
            <li>T&iacute;tulos: Centrado, altas y bajas, Times New Roman, n&uacute;mero 12.</li>
            <li>Subt&iacute;tulos: Izquierda, altas y bajas, Times New Roman, n&uacute;mero 12.</li>
            <li>Extensi&oacute;n: 10 a 25 cuartillas.</li>
            <li>Referencias: forma Harvard (autor, a&ntilde;o: p&aacute;gina). La bibliograf&iacute;a se presentar&aacute; en el mismo sistema al final del art&iacute;culo.</li>
            <li>Notas al pie de p&aacute;gina deber&aacute;n numerarse consecutivamente.</li>
            <h4>Los trabajos deber&aacute;n entregarse antes del 31 de marzo de 2017</h4>
          </ol> 
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
           
</body>
<?php 
   include("footer.php") 
   ?>
</html>


