<!DOCTYPE html>
<html lang="en">
  <head>
  <title>ELCEPAPO</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

<link rel="stylesheet" type="text/css" href="../estilo.css">


<link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  
</head>
<body>
<?php
    include("navbar.php");
    ?>

 <center>
    <div style="margin:0px auto;width:90%;text-align:center;padding:0px;background-color:#1C8C65;color:white;border:0px solid black;"> <h1> MOOC </h1></div>
</center>   
  </body>
  <?php 
   include("footer.php") 
   ?>
</html>