<!DOCTYPE html>
<html lang="en">
  <head>
  <title>ELCPAPO</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" type="text/css" href="../estilo.css">
<link rel="stylesheet" type="text/css" href="../navbar.css">

<link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  
  
</head>
 <body style="background: #59c206">
 

<?php
    require("navbar.php");
    ?>
 

    <!-- Full Page Image Background Carousel Header -->
    <center><header id="myCarousel" class="carousel slide" style="width: 95%">
            <!-- Wrapper for Slides -->
        <div class="carousel-inner" >

 <div class="item active" >
        <img src="../imagenes/1.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          
        </div>
      </div>
          
               
    </header>
    </center>

    <!-- Page Content -->
    <div class="container">
<font color="black">
        <div class="row">
            <div class="col-lg-12">
                <h2><p  style="color: #ffffff">Ciencias Políticas y Administración Pública</p></h2>
                          <h4> RVOE ES032/2013 • 11/11/2013 • SEV


<br>
<br>
              <center>
  <button type="button" class="btn danger" data-toggle="modal" data-target="#myModal">REQUISITOS</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header" >
          <button type="button" class="close"  data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Requisitos</h4>
        </div>
        <div class="modal-body">
         <p>• Original y 3 copias fotostáticas del acta de nacimiento.</p>
                <p> • Original y 3 copias fotostáticas del certificado de bachillerato (según sea el caso).</p>
                <p> • 3 copias fotostáticas de la CURP.</p>
                <p> • Para el caso de extranjeros, dos copias de la forma migratoria correspondiente.</p>
                <p> • 6 fotografías tamaño infantil.</p>
                <p> • Cubrir la cuota de inscripción y derechos respectivos.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
<!--boton-->

<a href="../solicitudes/solicitud de inscripción.doc" ><button type="button" class="btn danger" >SOLICITUD DE INSCRIPCIÓN</button></a>

</center>
       
 <br>

    <p> Objetivo: </p>

    <p>Formar especialistas en el área de las relaciones sociales y controlar las diferentes modalidades de la planeación administrativa, la toma de decisiones, considerando las diferentes implicaciones políticas inherentes a las formas de organización, comunicación y práctica administrativa, a las que se incorporará con sentido práctico, crítico y renovador.</p><br>

    <p>Asimismo conoce el marco jurídico normativo de la Administración Pública en los ámbitos Ejecutivo, Legislativo y Judicial, distinguiendo la importancia del sector paraestatal en México. Propone estrategias administrativas para armonizar las formas de organización del sector público federal, con las necesidades de una buena administración local. Relaciona la problemática municipal con el análisis del desarrollo regional y maneja las cuestiones técnicas y operacionales necesarias a su mejoramiento.</p>
    
<br>
                    </div>
            </div>
        </div>
        </h4>
</font>
<div class="contenedor" >
    <center>
        <img id=2 onclick="window.open('../plan/Ciencias Políticas y Administración Pública.pdf') " src="../imagenes/estudio.png">
        <h4> <span class="label label-danger">Plan de estudio </span>  </h4>
    </center>
</div>
</div>
    
<hr>

 <!-- SEGUNDO RVOE - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  - - - - - - -  -->
<div class="container">
<font color="black">
        <div class="row">
            <div class="col-lg-12">
                <h2><p  style="color: #ffffff">Ciencias Políticas y Administración Pública</p></h2>
                          <h4> SEGUNDO RVOE 


<br>
<br>
              <center>
  <button type="button" class="btn danger" data-toggle="modal" data-target="#myModal">REQUISITOS</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header" >
          <button type="button" class="close"  data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Requisitos</h4>
        </div>
        <div class="modal-body">
         <p>• Original y 3 copias fotostáticas del acta de nacimiento.</p>
                <p> • Original y 3 copias fotostáticas del certificado de bachillerato (según sea el caso).</p>
                <p> • 3 copias fotostáticas de la CURP.</p>
                <p> • Para el caso de extranjeros, dos copias de la forma migratoria correspondiente.</p>
                <p> • 6 fotografías tamaño infantil.</p>
                <p> • Cubrir la cuota de inscripción y derechos respectivos.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
<!--boton-->

<a href="../solicitudes/solicitud de inscripción.doc" ><button type="button" class="btn danger" >SOLICITUD DE INSCRIPCIÓN</button></a>

</center>
       
 <br>

    <p> Objetivo: </p>

    <p>Formar especialistas en el área de las relaciones sociales y controlar las diferentes modalidades de la planeación administrativa, la toma de decisiones, considerando las diferentes implicaciones políticas inherentes a las formas de organización, comunicación y práctica administrativa, a las que se incorporará con sentido práctico, crítico y renovador.</p><br>

    <p>Asimismo conoce el marco jurídico normativo de la Administración Pública en los ámbitos Ejecutivo, Legislativo y Judicial, distinguiendo la importancia del sector paraestatal en México. Propone estrategias administrativas para armonizar las formas de organización del sector público federal, con las necesidades de una buena administración local. Relaciona la problemática municipal con el análisis del desarrollo regional y maneja las cuestiones técnicas y operacionales necesarias a su mejoramiento.</p>
    
<br>
                    </div>
            </div>
        </div>
        </h4>
</font>

<div class="contenedor" >
    <center>
    <!-- coloca el plan de estudios en la siguiente ruta.... -->
        <img id=2 onclick="window.open('../plan/Ciencias Políticas y Administración Pública.pdf') " src="../imagenes/estudio.png">
        <h4> <span class="label label-danger">Plan de estudio </span>  </h4>
    </center>
</div>
</div>





  </body>
  <?php 
   include("footer.php") 
   ?>
</html>