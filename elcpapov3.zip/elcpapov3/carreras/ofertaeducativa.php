<!DOCTYPE html>
<html lang="en">
<head>
  <title>Oferta Educativa</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="../estiloformatos.css">
  <link rel="stylesheet" href="../css/estilosTexto.css">
 
   <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
</head>
<body>
 <?php
    include("navbar.php");
    ?>
<center>
<center>
    <div class="texto marco" style="float: none;">
        <div class="titulo">
            <h1>OFERTA EDUCATIVA</h1>  
        </div>
    </div>
</center>
</center>

        <div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="panel-group" id="accordion">
                
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #5ead33">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" style="color: #fff">Licenciaturas</a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <a href="ciencias-politicas.php" aria-controls="tab1" role="tab" style="color: #5ead33">Ciencias Políticas y Administración Pública</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="gestion-y-desarrollo.php" aria-controls="tab2" role="tab" style="color: #5ead33">Gestión y Desarrollo Municipal</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="seguridad-publica.php" aria-controls="tab3" role="tab" style="color: #5ead33">Seguridad Pública</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="politicas-publicas.php" aria-controls="tab3" role="tab" style="color: #5ead33">Políticas Públicas</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="pedagogia.php" aria-controls="tab3" role="tab" style="color: #5ead33">Pedagogía</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="administracion-empresas.php" aria-controls="tab3" role="tab" style="color: #5ead33">Administración de Empresas</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="derecho-gubernamental.php" aria-controls="tab3" role="tab" style="color: #5ead33">Derecho Gubernamental</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #5ead33">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" style="color: #fff">Maestrías</a>
                        </h4>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <a href="maestria-gobierno-administracion.php" aria-controls="tab4" role="tab" style="color: #5ead33">Gobierno y Administración Pública</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="administracion-de-personal.php" aria-controls="tab5" role="tab" style="color: #5ead33">Administración de Personal Público</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="maestria-gestion-y-desarrollo.php" aria-controls="tab6" role="tab" style="color: #5ead33">Gestión y Desarrollo Municipal</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="maestria-educacion.php" aria-controls="tab5" role="tab" style="color: #5ead33">Educación</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="maestria-seguridad-publica.php" aria-controls="tab6" role="tab" style="color: #5ead33">Seguridad Pública</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #5ead33">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour" style="color: #fff">Doctorados</a>
                        </h4>
                    </div>
                    <div id="collapseFour" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <a href="gobierno-y-administracion.php" aria-controls="tab7" role="tab" style="color: #5ead33">Gobierno y Administración Pública</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="doctorado-educacion.php" aria-controls="tab8" role="tab" style="color: #5ead33">Educación</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="ciencias-area-politica.php" aria-controls="tab9" role="tab" style="color: #5ead33">Ciencias en el Área de Ciencia Política</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #5ead33">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFive" style="color: #fff">Especialidades</a>
                        </h4>
                    </div>
                    <div id="collapseFive" class="panel-collapse collapse">
                        <div class="panel-body">
                            <table class="table">
                                <tr>
                                    <td>
                                        <a href="estudios-electorales.php" aria-controls="tab7" role="tab" style="color: #5ead33">Estudios Electorales</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="analisis-politico.php" aria-controls="tab8" role="tab" style="color: #5ead33">Análisis Político</a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                 <div class="panel panel-default">
                    <div class="panel-heading" style="background: #5ead33">
                        <h4 class="panel-title">
                            <a data-parent="#accordion" href="diplomados.php" style="color: #fff">Diplomados</a>
                        </h4>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" style="background: #5ead33">
                        <h4 class="panel-title">
                            <a data-parent="#accordion" href="MOOC.php" style="color: #fff">MOOC</a>
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php 
   include("footer.php") 
   ?>
</html>



