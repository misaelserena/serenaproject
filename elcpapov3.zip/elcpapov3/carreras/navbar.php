<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<script src="../js/jquery-latest.js"></script>    
<link rel="stylesheet" type="text/css" href="../css/reset.css">
<link rel="stylesheet" type="text/css" href="../css/navbar.css">	
<script type="text/javascript" src="../js/menuresponsive.js"></script>



<header class="newcontainer">
<div><img src="../imagenes/headerprueba.png" class="img-responsive" width="100%"></div>		
	<nav class="navbar">
	  	<div class="newcontainer-fluid">			    
			<div class="newnavbar-header">
			<a class="newnavbar-brand" href="../index.php"><img src="../imagenes/icono.png" class="img-responsive"> </a>
			     <button type="button" class="newnavbar-toggle" data-toggle="collapse" data-target="#menu">			        
			        	<span class="icon-bar"></span>
			        	<span class="icon-bar"></span>
			        	<span class="icon-bar"></span>
			     </button>
			     
			</div>
			
			<div class="collapse newnavbar-collapse" id="menu">
			     <ul class="newnavbar-nav">
			        	<li class="newdropdown"><a href="../nosotros.php">Nosotros</a>
			          	<ul class="newdropdown-menu">
				            	<li><a href="../misionvision.php">Misi&oacute;n y Visi&oacute;n</a></li>
		                    	<li><a href="../objetivos.php">Objetivos</a></li>
		                    	<li><a href="../organigrama.php">Organigrama</a></li>
				          </ul>
			        	</li>

			        	<li class="newdropdown"><a href="ofertaeducativa.php">Oferta Educativa</a>
			          	<ul class="newdropdown-menu">
				            	<li class="newdropdown"><a href="#" class="newdropdown-toggle">Licenciaturas</a>
						          <ul class="newdropdown-menu">
						            	<li><a href="ciencias-politicas.php" title="">Ciencias Políticas y Administración Pública</a></li>
		                            		<li><a href="derecho-gubernamental.php" title="">Derecho Gubernamental</a></li>
		                            		<li><a href="gestion-y-desarrollo.php" title="">Gestión y Desarrollo Municipal</a></li>
		                            		<li><a href="seguridad-publica.php" title="">Seguridad Pública</a></li>
		                            		<li><a href="politicas-publicas.php" title="">Políticas Públicas</a></li>
		                            		<li><a href="pedagogia.php" title="">Pedagogía</a></li>
		                            		<li><a href="administracion-empresas.php" title="">Administración de Empresas</a></li>
						          </ul>
					        	</li>
					        	<li class="newdropdown"><a href="#" class="newdropdown-toggle">Maestrias</a>
						          <ul class="newdropdown-menu">
						            	<li><a href="maestria-gobierno-administracion.php" title="">Gobierno y Administración Pública</a></li>
		                            		<li><a href="administracion-de-personal.php" title="">Administración de Personal Público</a></li>
		                            		<li><a href="maestria-gestion-y-desarrollo.php" title="">Gestión y Desarrollo Municipal</a></li>
		                            		<li><a href="maestria-educacion.php" title="">Educación</a></li>
		                            		<li><a href="maestria-seguridad-publica.php" title="">Seguridad Pública</a></li>
						          </ul>
					        	</li>
					        	<li class="newdropdown"><a href="#" class="newdropdown-toggle">Doctorados</a>
						          <ul class="newdropdown-menu">
						            	<li><a href="gobierno-y-administracion.php" title="">Gobierno y Administración Pública</a></li>
		                            		<li><a href="doctorado-educacion.php" title="">Educación</a></li>
		                            		<li><a href="ciencias-area-politica.php" title="">Ciencias en el Área de Ciencia Política</a></li>
						          </ul>
					        	</li>
					        	<li class="newdropdown"><a href="#" class="newdropdown-toggle">Especialidades</a>
						          <ul class="newdropdown-menu">
						            	<li><a href="estudios-electorales.php" title="">Estudios Electorales</a></li>
		                            		<li><a href="analisis-politico.php" title="">Análisis Político</a></li>
						          </ul>
					        	</li>
				            	<li><a href="diplomados.php">Diplomados</a></li>
		                    	<li><a href="MOOC.php">MOOC</a></li>
			          	</ul>
			        	</li>

			        	<li><a href="http://www.elcpapo.edu.mx/campusvirtual/index.htm" title="">Aula Virtual</a></li>

			        	<li class="newdropdown"><a href="../serviciosEscolares.php">Servicios Escolares y Administrativos</a>
			          	<ul class="newdropdown-menu">
				            	<li><a href="../formatos.php">Formatos</a></li>
		                    	<li><a href="#">Area Acadenica</a></li>
		                    	<li><a href="#">Area Administrativa</a></li>
				          </ul>
			        	</li>

			        	<li class="newdropdown"><a href="#" class="newdropdown-toggle">Divulgacion</a>
			          	<ul class="newdropdown-menu">
				            	<li><a href="../divulgacion.php">Noticias</a></li>
		                    	<li><a href="../revistas.php">Revistas</a></li>
		                    	<li><a href="#">Articulos</a></li>
			          	</ul>
			        	</li>

			        	<li class="newdropdown"><a href="../recursos.php">Recursos</a>
			          	<ul class="newdropdown-menu">
				            	<li><a href="../login.php">Biblioteca Virtual</a></li>
		                    	<li><a href="../diccionario.php">Diccionario Virtual</a></li>
			          	</ul>
			        	</li>

			        	<li><a href="contacto.php" title="">Contacto</a></li>

			     </ul>			      
			</div>
		</div>
	</nav>		
</header>