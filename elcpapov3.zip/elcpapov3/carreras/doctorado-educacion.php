<!DOCTYPE html>
<html lang="en">
  <head>
  <title>ELCPAPO</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" type="text/css" href="../estilo.css">
<link rel="stylesheet" type="text/css" href="../navbar.css">

<link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  
  
</head>
 <body style="background: #59c206">
 
<?php
    require("navbar.php");
    ?>

 

   <!-- Full Page Image Background Carousel Header -->
    <center><header id="myCarousel" class="carousel slide" style="width: 95%">
            <!-- Wrapper for Slides -->
        <div class="carousel-inner" >

 <div class="item active" >
        <img src="../imagenes/7.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          
        </div>
      </div>

    </header>
    </center>

    <!-- Page Content -->
    <div class="container">
<font color="black">
        <div class="row">
            <div class="col-lg-12">
                <h2><p  style="color: #ffffff">Educación</p></h2>
                          <h4> RVOE ES059/2003 • 05/09/2003 • SEV


<br>
<br>
              <center>
  <button type="button" class="btn danger" data-toggle="modal" data-target="#myModal">REQUISITOS</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header" >
          <button type="button" class="close"  data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Requisitos</h4>
        </div>
        <div class="modal-body">
         <p>• 3 copias fotostáticas del certificado de estudios completos de especialidad, especialidad médica o maestría debidamente legalizado (según sea el caso).</p>
<p>• 3 copias fotostáticas del Diploma de Especialidad o Grado de Maestría y/o Acta de Examen y/o Cédula Profesional, en caso de no contar con estos documentos, el aspirante deberá presentar carta compromiso de forma de titulación y tiempo de la misma.</p>
<p>• 3 copias fotostáticas del Acta de Nacimiento.</p>
<p>• 3 copias fotostáticas de la CURP</p>
<p>• Para el caso de extranjeros, 3 copias de la forma migratoria correspondiente.</p>
<p>• 6 fotografías tamaño infantil a color con fondo azul y ropa clara.</p>
<p>• Cubrir la cuota de inscripción y derecho respectivos.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
<!--boton-->

<a href="../solicitudes/solicitud de inscripción.doc" ><button type="button" class="btn danger" >SOLICITUD DE INSCRIPCIÓN</button></a>

</center>
       
 <br>

   <p> Objetivo: </p>
 <p>La formación de  investigadores capaces de comprender y explicar los problemas educativos específicos de una área, empleando, de manera consistente, las aportaciones derivadas de diversas perspectivas disciplinares, así como las herramientas metodológicas pertinentes para abordar distintos problemas de investigación. Además de contribuir a la generación de nuevos conocimientos para interpretar y proponer soluciones a los problemas educativos de México.</p>
        
    
                    </div>
            </div>
        </div>
        </h4>
</font>
<div class="contenedor" >
    <center>
        <img id=2 onclick="window.open('../plan/Educación-D.pdf') " src="../imagenes/estudio.png">
        <h4> <span class="label label-danger">Plan de estudio </span>  </h4>
    </center>
</div>

     

    </div>
  
  </body>
  <?php 
   include("footer.php") 
   ?>
</html>