<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Acerca de ELCPAPO</title>
		<link rel="stylesheet" type="text/css" href="css/estilosTexto.css">
		<link rel="stylesheet" type="text/css" href="css/w3.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
	  	<script src="js/jquery.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
	</head>
	
	<body >
		<?php 
		include("navbar.php");
		?>
		<center>
			<div class="row">
				<div class="col-sm-6">
					<img src="imagenes/mision.jpg" alt="">
				</div>
				<div class="col-sm-6" >
					<div class="titulo">
						<h1><strong>Misi&oacute;n</strong></h1>	
					</div>
					<div style="border-bottom: 2px #f8a9df;">
						<br>
			  			<p>Proporcionar con un alto nivel de calidad científica y académica programas de Licenciatura y postgrados en las áreas de las Ciencias Sociales, específicamente dentro de las ciencias políticas, la administración pública, la educación y el derecho. Ser responsable directo de la formación de los científicos sociales que demanda el País México y el Estado de Veracruz. Siempre con un alto nivel en la docencia y en la investigación.</p>
			  			<br><br>
		  			</div>
		  		</div>
		  		<div class="col-sm-6" >
		  			<div class="titulo">
		  				<h1><strong>Visi&oacute;n</strong></h1>
		  			</div>
		  			<div>
			  			<br>
			  			<p>Buscar constituirse en la institución número uno en el País, especializada en docencia e investigación de las ciencias políticas y la administración pública. Proporcionando un alto nivel académico y científico en sus programas de licenciatura, especialidad, maestría y doctorado, así como en sus cursos de educación contínua.</p>
			  			<br><br><br>
		  			</div>
				</div>
				<div class="col-sm-6">
					<img src="imagenes/vision.jpg" alt="">
				</div>
			</div>
		</center>
		<br><br>
	</body>
		<?php 
   include("footer.php");
   ?>

</html>