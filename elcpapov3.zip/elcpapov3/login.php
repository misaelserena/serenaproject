<?php	
include("conexion.php");
	session_start();
	
	if(isset($_SESSION["id_usuario"])){
		header("Location: alumno/home.php");
	}
	
	if(!empty($_POST))
	{
		$usuario = mysqli_real_escape_string($mysqli,$_POST['usuario']);
		$password = mysqli_real_escape_string($mysqli,$_POST['password']);
		$error = '';
		
		$sha1_pass = sha1($password);
		
		$sql = "SELECT idUsuario, usuario, TiposUsuario_idTipo FROM usuarios WHERE usuario = '$usuario' AND password = '$sha1_pass'";
		$result=$mysqli->query($sql);
		$rows = $result->num_rows;
		
		if($rows > 0) {
			$row = $result->fetch_assoc();
			$_SESSION['id_usuario'] = $row['idUsuario'];
			$_SESSION['tipo_usuario'] = $row['TiposUsuario_idTipo'];
            $_SESSION['usuario'] = $row['usuario'];
            
            
            if($_SESSION['tipo_usuario']==1) {
            	header("Location: admin/home.php");
           	}else{
                header("location: alumno/home.php");
            }
			
		} else {
			$error = "El nombre o contrase&ntilde;a son incorrectos";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Login Biblioteca</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	<script>
			function validarNombre()
			{
				valor = document.getElementById("nombre").value;
				if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
					alert('Falta Llenar Nombre');
					return false;
				} else { return true;}
			}

            function validarEdad()
            {
                valor = document.getElementById("edad").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Faltar Llenar Edad');
                    return false;
                } else { return true;}
            }

            function validarDireccion()
            {
                valor = document.getElementById("direccion").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Faltar Llenar Dirección');
                    return false;
                } else { return true;}
            }

            function validarEmail()
            {
                valor = document.getElementById("correo").value;
                if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
                    alert('Faltar Llenar Correo Electrónico');
                    return false;
                } else { return true;}
            }
			
			function validarUsuario()
			{
				valor = document.getElementById("user").value;
				if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
					alert('Falta Llenar Usuario');
					return false;
				} else { return true;}
			}
			
			function validarPassword()
			{
				valor = document.getElementById("password").value;
				if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
					alert('Falta Llenar Password');
					return false;
					} else { 
					valor2 = document.getElementById("con_password").value;
					
					if(valor == valor2) { return true; }
					else { alert('Las contraseña no coinciden'); return false;}
				}
			}
			
			
			function validar()
			{
				if(validarNombre() && validarUsuario() && validarPassword() && validarEdad() && validarDireccion() && validarEmail())
				{
					document.registro.submit();
				}
			}
			
		</script>
    
</head>
<body>
   <?php include("navbar.php"); ?>
<br><br>
<div class="container">
    
    <div class="row col-md-4 col-md-offset-4" >
        <br>
        <div class="panel panel-default"  style="border-radius: 20px 20px 20px 20px">
            <div class="panel-heading text-center"  style="border-radius: 20px 20px 20px 20px">
                <h3 class="form-signin-heading">Iniciar Sesi&oacute;n</h3>
            </div>
            <div class="panel-body">
                <form class="form-signin form-login" role="form" method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
                    <div class="form-group">
                        <label for="usuario" class="control-label">Usuario:</label>
                        <input type="text" id="usuario" name="usuario" class="form-control" placeholder="Usuario" required autofocus>
                    </div>
                    <div class="form-group">
                        <label for="pass" class="control-label">Contraseña:</label>
                        <input type="password" id="pass" name="password" class="form-control" placeholder="Contraseña" required>
                    </div>
                    <div class="form-group">
                        <input name="login" type="submit" class="btn btn-primary" value="Iniciar">
                    </div> 
                </form>
                <div  style = "color: #a94442;background-color: #f2dede; border-color: #ebccd1;"><?php echo isset($error) ? utf8_decode($error) : '' ; ?></div>
            </div>
        </div>
    </div>
</div>


</body>
<?php 
   include("footer.php") 
   ?>
</html>