<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Organigrama</title>
	<link rel="stylesheet" href="css/estilos.css">
			<link rel="stylesheet" type="text/css" href="css/w3.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
	  	<script src="js/jquery.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
</head>
<body>
	<?php
    include("navbar.php");
    ?>
	<center>
	<a href="Archivos/directorio.pdf" target="blank" class="btn btn-info btn-lg">Directorio</a>
		<div class="organigrama">
			<img src="imagenes/organigrama.jpg" width="50%" height="50%">
		</div>
	</center>
			<br><br>
</body>

<?php 
   include("footer.php") 
   ?>
</html>