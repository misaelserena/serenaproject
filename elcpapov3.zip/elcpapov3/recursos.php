<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Recursos</title>
    <link rel="stylesheet" href="">

    <link rel="stylesheet" href="css/estilosTexto.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>
<body>
    
     <?php
    include("navbar.php");
    ?>
    
    <center>
        <div class="texto marco" style="float: none;">
            <div class="titulo">
                <h1>Recursos</h1>  
            </div>
        </div>
    </center>

    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="panel-group" id="accordion">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading" style="background: #5ead33">
                            <h4 class="panel-title">
                                <a href="biblioteca.php" style="color: #fff">Biblioteca Virtual</a>
                            </h4>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading" style="background: #5ead33">
                            <h4 class="panel-title">
                                <a href="diccionario.php" style="color: #fff">Diccionario Virtual</a>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
<?php 
   include("footer.php") 
   ?>
</html>