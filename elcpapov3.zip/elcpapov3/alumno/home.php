<?php
include("../conexion.php");


session_start();
$user = $_SESSION['usuario'];
$idUsuario = $_SESSION['id_usuario'];
if(isset($_SESSION['usuario'])){
    if($_SESSION['tipo_usuario'] == 2){
    }else{
        header("Location: ../admin/home.php");
    }
}else{
    header("Location: ../index.php");
}


?>

<!DOCTYPE html>
<!--
Autor: Serena
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Biblioteca</title>
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
        
        <script src="../js/jquery-latest.js"></script>    
<link rel="stylesheet" type="text/css" href="../css/reset.css">
<link rel="stylesheet" type="text/css" href="../css/navbar.css">   
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/menuresponsive.js"></script>

    </head>
    <body>

    <?php 
        include("navbarBiblioteca.php");
     ?>

<div style="width: 100%; background: #fff; border-radius: 20px 20px 20px 20px; border: 2px solid  #1f3282 ; max-width: 1200px; width: 95%; margin: auto;">
<div class="w3-container" style="border-bottom: 2px solid #1f3282; border-radius: 19px 19px 0 0; background: #2471a3;">
<?php
    try {
        $base = new PDO('mysql:host=localhost; dbname=elcpapo','root','serena1');
        
        $base->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $base->exec("SET CHARACTER SET UTF8");
        
    }catch(Exception $e) {
        die('Error'. $e->getMessage());
        echo "linea del error" . $e->gerLine();
    }
    $sqlinfo="select personal.name fullname from personal, usuarios where usuarios.Personal_idPersonal=personal.id and usuarios.usuario='$user';";
    $conexion=$base->query($sqlinfo);
    $registros=$conexion->fetchAll(PDO::FETCH_OBJ);
?>
<?php foreach ($registros as $info): ?>
  <center><h2 style="color: #fff;"><b>Bienvenido(a) <?php echo $info->fullname; ?> <?php endforeach ?>  a nuestra Biblioteca Virtual</b></h2></center>  
</div>
<div class="w3-row-padding">

<div class="w3-third" st>
<center><h3><b>Licenciatura</b></h3></center>
        <p style="padding-left: 10px;">En esta secci&oacute;n encontrará libros de su interés como... Además de contar con libros de reconocidos autores.</p>
        <center><img src="../imagenes/iconolic.png" alt="Licenciaturas"></center><br>
        <center><a href="licenciaturas.php" class="btn btn-primary">Ver Libros</a></center><br>
</div>

<div class="w3-third">
<center><h3><b>Maestr&iacute;a</b></h3></center>
        <p style="padding-left: 10px;">En esta secci&oacute;n encontrará libros de su interés como... Además de contar con libros de reconocidos autores.</p>
        <center><img src="../imagenes/iconomae.png" alt="Maestr&iacute;as"></center><br>
        <center><a href="maestrias.php" class="btn btn-primary">Ver Libros</a></center><br>
</div>

<div class="w3-third">
<center><h3><b>Doctorado</b></h3></center>
        <p style="padding-left: 10px;">En esta secci&oacute;n encontrará libros de su interés como... Además de contar con libros de reconocidos autores.</p>
        <center><img src="../imagenes/iconodoc.png" alt="Doctorados"></center><br>
        <center><a href="doctorados.php" class="btn btn-primary">Ver Libros</a></center><br>
</div>
</div> 
</div> 
    </body>

</html>
