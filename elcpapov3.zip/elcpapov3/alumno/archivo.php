<!DOCTYPE html>
<!--
Autor: Serena
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include 'conexion.php';
        $db=new Conect_MySql();
            $sql = "select*from libros where id_documento=".$_GET['id'];
            $query = $db->execute($sql);
            if($datos=$db->fetch_row($query)){
                if($datos['nombre_archivo']==""){?>
        <p>NO tiene archivos</p>
                <?php }else{ ?>
        <iframe width="800px;" height="600px;" src="archivos/<?php echo $datos['nombre_archivo']; ?>"></iframe>
                
                <?php } } ?>
    </body>
</html>
