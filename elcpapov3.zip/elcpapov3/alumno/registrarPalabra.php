<!DOCTYPE html>
<html>
<head>
    <title></title>
<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script src="../css/sweetalert.min.js"></script>
</head>
<body>
</body>
</html>

<?php
$conexion = mysqli_connect("localhost","root","serena1","elcpapo");
if(!conexion){
echo 'Error al conectar bd';
}
else{
}

$palabra = $_POST['palabra'];
$significado = $_POST['significado'];
$estado="no aprobado";

$insertar = "INSERT INTO diccionario(palabra,significado,estado) VALUES ('$palabra','$significado','$estado')";
$resultado = mysqli_query($conexion,$insertar);

if (!$resultado) {
    echo "no enviado";
}else{
    echo "<script>
           swal({
  title: 'Palabra Enviada',
  text: 'La palabra $palabra ha sido enviada para su revisión!',
  type: 'success',
  confirmButtonColor: '#DD6B55',
  confirmButtonText: 'Aceptar',
  closeOnConfirm: true
},
function(isConfirm){
  if (isConfirm) {
  	window.location.href='../diccionario.php'
  } else {
        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
  }
});
          </script>";
}
?>