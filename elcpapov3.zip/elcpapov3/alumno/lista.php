<?php
            include 'conexion.php';
            $db=new Conect_MySql();
                $sql = "select*from libros";
                $query = $db->execute($sql);
                while($datos=$db->fetch_row($query)){
            ?>
                     <div class="card"><br>
                      <center><img src="imagenes/libro.png" alt="Libro"></center>
                      <div class="container">
                        <h4 style="width: 150px;"><b><?php echo $datos['titulo']; ?></b></h4>
                        <p><?php echo $datos['descripcion']; ?></p>
                        <p><?php echo $datos['categoria']; ?></p>
                        <a style="width: 150px; background: #1f3282;" class="btn btn-primary" href="archivo.php?id=<?php echo $datos['id_documento']?>" target="popup" onclick="window.open('', 'popup', 'width = 800, height = 600')">Abrir</a><br><br>
                      </div>
                    </div>
                <?php  } ?> 