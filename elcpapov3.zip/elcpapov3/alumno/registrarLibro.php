<!DOCTYPE html>
<html>
<head>
    <title></title>
<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script src="../css/sweetalert.min.js"></script>
</head>
<body>


</body>
</html>

<?php
include_once 'conexion.php';

    $nombre = $_FILES['archivo']['name'];
    $tipo = $_FILES['archivo']['type'];
    $tamanio = $_FILES['archivo']['size'];
    $ruta = $_FILES['archivo']['tmp_name'];
    $destino = "archivos/" . $nombre;
    if ($_FILES['archivo']['type'] == "application/pdf") {
        if ($nombre != "") {
            if (copy($ruta, $destino)) {
                $titulo= $_POST['titulo'];
                $categoria=$_POST['categoria'];
                $estado="no aprobado";
                $db=new Conect_MySql();
                $sql = "INSERT INTO libros(titulo,categoria,tamanio,tipo,nombre_archivo,estado) VALUES('$titulo','$categoria','$tamanio','$tipo','$nombre','$estado')";
                $query = $db->execute($sql);
                if($query){
                    echo "<script>
                           swal({
                                  title: 'Agregado',
                                  text: 'El libro ha sido enviado para su revisión!',
                                  type: 'success',
                                  confirmButtonColor: '#DD6B55',
                                  confirmButtonText: 'Aceptar',
                                  closeOnConfirm: true
                                },
                                function(isConfirm){
                                  if (isConfirm) {
                                    window.history.back();
                                  } else {
                                        swal('Cancelled', 'Your imaginary file is safe :)', 'error');
                                  }
                                });
                          </script>";
                }
            } else {
                echo "Error";
            }
        }
    }else{
        echo "<script>
               swal({
                      title: 'Error',
                      text: 'El libro tiene que estar en formato PDF',
                      type: 'error',
                      confirmButtonColor: '#DD6B55',
                      confirmButtonText: 'Aceptar',
                      closeOnConfirm: true
                    },
                    function(isConfirm){
                      if (isConfirm) {
                        window.history.back();
                      } else {
                            swal('Cancelled', 'Your imaginary file is safe :)', 'error');
                      }
                    });
            </script>";
    }
   

?>