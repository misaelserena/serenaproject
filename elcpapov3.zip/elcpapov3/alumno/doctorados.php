<?php
include("../conexion.php");



session_start();
$user = $_SESSION['usuario'];
if(isset($_SESSION['usuario'])){
    if($_SESSION['tipo_usuario'] == 1){
        
    }else{
    }
}else{
    header("Location: ../login.php");
}

?>
<!DOCTYPE html>
<!--
Autor: Serena
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Biblioteca</title>
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <script src="../js/jquery.min.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/main.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/navbar.css">
        <script src="../js/jquery-latest.js"></script>    
        <link rel="stylesheet" type="text/css" href="../css/reset.css"> 
        <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    </head>
    <body>
   <?php 
        include("navbarBiblioteca.php");
     ?>
<!-- SECCION PARA AGREGAR NUEVO LIBRO_____________________________________________________________ -->
          <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Agregar Nuevo Libro</h4>
        </div>
        <div class="modal-body">
                <form method="post" action="registrarLibro.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="control-label" for="titulo">Categoria</label>
                        <select name="categoria" class="form-control">
                            <option class="form-control" value="Licenciatura">Licenciatura</option>
                            <option class="form-control" value="Maestria">Maestr&iacute;a</option>
                            <option class="form-control" value="Doctorado">Doctorado</option>
                            <option class="form-control" value="Diplomado">Diplomado</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="titulo">T&iacute;tulo</label>
                        <input type="text" name="titulo" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="archivo">Seleccionar libro en formato PDF</label>
                        <input type="file" name="archivo" class="form-control" style="height: 40px;">
                    </div>
                                
        </div>
        <div class="modal-footer">
        <div class="form-group">
        <input type="submit" value="Agregar" name="subir" class="btn btn-primary" style="background: #262072;">                 
        </div>
                </form>
        </div>
      </div> 
    </div>
  </div>
<!-- _____ FIN PARA AGREGAR NUEVO LIBRO ___________________________________________________________________________________ -->

<div class="w3-container">
<div><br>
        <center><button class="btn btn-primary" onclick="location.href='home.php'">Regresar</button></center><br>
    </div>
 
<div class="w3-row-padding" style="max-width: 1200px; width: 95%; margin: auto;">
<div class="w3-half">
  <label>Agregar Libro: </label> <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Agregar</button>
</div>
<div class="w3-half">
  <form action="busquedadoctorado.php" method="post" target="popup">
        <label class="control-label">Buscar: </label>
        <input type="text" name="busqueda">
        <input type="submit" name="buscar" value="Buscar" class="btn btn-primary" onclick="window.open('', 'popup', 'width = 800, height = 600')">
    </form>
</div>
</div>
</div>
<br>

<div class="contenidobiblioteca">
    <div class="w3-row-padding">
        <?php
                include 'conexion.php';
                $db=new Conect_MySql();
                    $sql = "select*from libros where categoria='doctorado' and estado='aprobado'";
                    $query = $db->execute($sql);
                    while($datos=$db->fetch_row($query)){
                ?>
                <div class="w3-quarter">
                         <div class="card"><br>
                          <center><img src="../imagenes/libro.png" alt="Libro"></center>
                          <div class="container">
                            <h6><b><?php echo substr($datos['titulo'],0,23)."..." ?></b></h6>
                            <p class="categoria"><?php echo $datos['categoria']; ?></p>
                            <a style="width: 100px; background: #1f3282;" class="btn btn-primary" href="archivo.php?id=<?php echo $datos['id_documento']?>" target="popup" onclick="window.open('', 'popup', 'width = 800, height = 600')">Abrir</a><br><br>
                          </div>
                        </div>
                </div>
                    <?php  } ?> 
    </div>
</div>
    
    </body>
</html>