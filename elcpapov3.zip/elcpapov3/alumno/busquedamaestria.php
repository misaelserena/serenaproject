        <link rel="stylesheet" type="text/css" href="../css/estilosbiblioteca.css">
        <link rel="stylesheet" href="../css/w3.css">
        <script src="../js/jquery.min.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/main.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/navbar.css">


<div class="contenidobiblioteca">
<br><button style="margin-left: 20px;" class="btn btn-primary" onclick="window.close()">Regresar</button><br><br>
    <div class="w3-row-padding">
        <?php
                include 'conexion.php';
                $db=new Conect_MySql();
                $busqueda=$_POST['busqueda'];
                    $sql = "select*from libros where categoria='maestria' and estado='aprobado' and titulo like '%$busqueda%'";
                    $query = $db->execute($sql);
                    while($datos=$db->fetch_row($query)){
                ?>
                <div class="w3-quarter">
                         <div class="card"><br>
                          <center><img src="../imagenes/libro.png" alt="Libro"></center>
                          <div class="container">
                            <h6><b><?php echo substr($datos['titulo'],0,23)."..." ?></b></h6>
                            <p class="categoria"><?php echo $datos['categoria']; ?></p>
                            <a style="width: 100px; background: #1f3282;" class="btn btn-primary" href="archivo.php?id=<?php echo $datos['id_documento']?>" target="popup" onclick="window.open('', 'popup', 'width = 800, height = 600')">Abrir</a><br><br>
                          </div>
                        </div>
                </div>
                    <?php  } ?> 
    </div>
</div>