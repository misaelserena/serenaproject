<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Acerca de ELCPAPO</title>
		<link rel="stylesheet" type="text/css" href="css/estilosTexto.css">
		<link rel="stylesheet" type="text/css" href="css/w3.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
	  	<script src="js/jquery.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
	</head>
	
	<body>
		<?php 
		include("navbar.php");
		?>

		<center>
			<div class="row">
				<div class="col-sm-6">
					<img src="imagenes/obe.jpg" alt="">
				</div>
				<div class="col-sm-6">
					<div class="titulo">
						<h1>Objetivo General</h1>
					</div>
			  		<div>	
			  			<br>
			  			<p>Formar Especialistas en Ciencia Política y Administración Pública con una sólida preparación científica y con un sentido humanista.</p>
			  			<br><br><br>
		  			</div>
				</div>
				<div class="col-sm-6">
					<div class="titulo">
						<h1>Objetivo Espec&iacute;fico</h1>	
					</div>
					<div>
			  			<br>
			  			<p>Impartir educación a nivel medio superior, superior, postgrado, diplomados, maestrías y doctorados.
			  			<br><br>
						Promover y difundir la cultura y la investigación científica entre sus miembros a través de toda clase de eventos culturales y afines al desarrollo de la investigación.
						<br><br>
						Celebrar contratos, convenios civiles o mercantiles necesarios para el desarrollo de los fines sociales.</p>
					</div>
				</div>
				<div class="col-sm-6">
					<img src="imagenes/obg.jpg" alt="">		
				</div>	
			</div>
		</center>
		
	</body>
	<br><br>
	<?php 
   include("footer.php");
   ?>
</html>